# -*- coding: utf-8 -*-
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, colorchooser, filedialog
import tkinter.font as tkfont
from pathlib import Path
from datetime import datetime
import hashlib, os, tempfile, webbrowser, html, json, threading, urllib.request, shutil, time, subprocess, zipfile, re

APP_TITLE = 'نظام إدارة الثوابت والذمم'
APP_VERSION = '1.4.0'
UPDATE_SOURCE_URL = 'https://raw.githubusercontent.com/safiymm89/MaintenanceSystem-Updates-Public/main/fixed_assets_version.json'
# رابط قديم كان مشتركاً مع برنامج الصيانة (يُستبدل تلقائياً بالرابط الخاص بهذا البرنامج)
OLD_UPDATE_URLS = ('https://raw.githubusercontent.com/safiymm89/MaintenanceSystem-Updates-Public/main/version.json',)
PROGRAM_FILE = 'FixedAssetsManagement.py'

DEFAULTS = {
    'password_hash': hashlib.sha256('1234'.encode('utf-8')).hexdigest(),
    'theme': 'فاتح', 'font_family': 'Tahoma', 'font_size': '10',
    'font_bold': '0', 'font_color': '#111111',
    'primary_color': '#2589ef', 'capsule_color': '#1677ff', 'heading_color': '#17283b', 'background_color': '#f4f7fb',
    'language': 'العربية', 'date_format': 'يوم/شهر/سنة',
    'show_row_numbers': '0', 'grid_lines': '1', 'row_select_color': '1', 'row_height': 'متوسط',
    'update_notify': '1', 'sounds': '0', 'autosave_settings': '1', 'confirm_delete': '1',
    'backup_path': '', 'backup_frequency': 'أسبوعي', 'update_auto_check': '1', 'language_hijri': '0', 'update_server': UPDATE_SOURCE_URL,
}
DEFAULT_DIVISIONS = ['شعبة الصيانة', 'شعبة الدفاع المدني', 'شعبة التغذية', 'شعبة المخزن', 'شعبة الآليات', 'شعبة المناهج', 'شعبة الاستعلامات']
DEFAULT_UNITS = ['الوحدة الإدارية', 'الوحدة الفنية', 'وحدة المخزن', 'وحدة الصيانة']
DEFAULT_CATEGORIES = ['أثاث', 'أجهزة كهربائية', 'أجهزة إلكترونية', 'أجهزة حاسوب', 'مستلزمات مكتبية', 'معدات', 'أخرى']
DEFAULT_ITEM_UNITS = ['قطعة', 'جهاز', 'طقم', 'متر', 'كرتون', 'كيلوغرام', 'لتر']

# ======================= أدوات أساسية (متانة + لغات) =======================
import unicodedata, logging, traceback, sys, calendar as _calendar
try:
    import winsound as _winsound
except Exception:
    _winsound = None

APP_DIR = Path(__file__).resolve().parent
BASE_DIR = APP_DIR


def _writable(p):
    try:
        t = Path(p) / '.write_test'
        t.write_text('1')
        t.unlink()
        return True
    except Exception:
        return False


# مجلد البيانات: بجانب البرنامج إن كان قابلاً للكتابة، وإلا مجلد المستخدم (حتى لا يتعطل البرنامج داخل Program Files)
DATA_DIR = BASE_DIR if _writable(BASE_DIR) else Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'FixedAssetsManagement'
try:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    DATA_DIR = Path(tempfile.gettempdir()) / 'FixedAssetsManagement'
    DATA_DIR.mkdir(parents=True, exist_ok=True)
DB = DATA_DIR / 'fixed_assets.sqlite'
if DATA_DIR != BASE_DIR and not DB.exists() and (BASE_DIR / 'fixed_assets.sqlite').exists():
    try:
        shutil.copy2(BASE_DIR / 'fixed_assets.sqlite', DB)
    except Exception:
        pass
LOG_FILE = DATA_DIR / 'error_log.txt'


def log_error(text):
    try:
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write('[' + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '] ' + text + '\n')
    except Exception:
        pass


class DataIntegrityError(Exception):
    """تُرفع عندما تجعل العملية رصيد المخزن أو ذمة موظف بالسالب."""


# ---------------- البحث العربي الذكي (يتجاهل الهمزات والتشكيل والأرقام الهندية) ----------------
_AR_TABLE = str.maketrans({'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي', 'ئ': 'ي', 'ؤ': 'و', 'ة': 'ه', 'ـ': None,
                           '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
                           '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9'})
_AR_MARKS = re.compile('[ً-ٰٟۖ-ۭ]')
_LIKE_CACHE = {}


def norm_ar(s):
    s = unicodedata.normalize('NFKC', str(s))
    return _AR_MARKS.sub('', s).translate(_AR_TABLE).casefold()


def _sql_like(pattern, value, escape=None):
    if pattern is None or value is None:
        return None
    key = (pattern, escape)
    rx = _LIKE_CACHE.get(key)
    if rx is None:
        p = norm_ar(pattern)
        out = []
        i = 0
        while i < len(p):
            ch = p[i]
            if escape and ch == escape and i + 1 < len(p):
                out.append(re.escape(p[i + 1]))
                i += 2
                continue
            out.append('.*' if ch == '%' else '.' if ch == '_' else re.escape(ch))
            i += 1
        rx = re.compile('^' + ''.join(out) + '$', re.S)
        if len(_LIKE_CACHE) > 500:
            _LIKE_CACHE.clear()
        _LIKE_CACHE[key] = rx
    return 1 if rx.match(norm_ar(value)) else 0


def open_db():
    conn = sqlite3.connect(str(DB), timeout=15)
    conn.execute('PRAGMA busy_timeout=15000')
    conn.create_function('like', 2, _sql_like)
    conn.create_function('like', 3, _sql_like)
    return conn


# ---------------- التاريخ الهجري (تقريبي) ----------------
def gregorian_to_hijri(y, m, d):
    jd = (1461 * (y + 4800 + (m - 14) // 12)) // 4 + (367 * (m - 2 - 12 * ((m - 14) // 12))) // 12 \
        - (3 * ((y + 4900 + (m - 14) // 12) // 100)) // 4 + d - 32075
    l = jd - 1948440 + 10632
    n = (l - 1) // 10631
    l = l - 10631 * n + 354
    j = ((10985 - l) // 5316) * ((50 * l) // 17719) + (l // 5670) * ((43 * l) // 15238)
    l = l - ((30 - j) // 15) * ((17719 * j) // 50) - (j // 16) * ((15238 * j) // 43) + 29
    mm = (24 * l) // 709
    dd = l - (709 * mm) // 24
    yy = 30 * n + j - 30
    return yy, mm, dd


_DATE_RX = re.compile(r'^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}:\d{2})(?::\d{2})?)?$')


def format_date_value(v, fmt='dmy', hijri=False):
    if not isinstance(v, str):
        return v
    m = _DATE_RX.match(v)
    if not m:
        return v
    y, mo, d, hm = m.group(1), m.group(2), m.group(3), m.group(4)
    try:
        yi, mi, di = int(y), int(mo), int(d)
    except ValueError:
        return v
    out = f'{d}/{mo}/{y}' if fmt == 'dmy' else f'{y}-{mo}-{d}'
    if hm:
        out += ' ' + hm
    if hijri:
        try:
            hy, hm_, hd = gregorian_to_hijri(yi, mi, di)
            out += f'  ({hd:02d}/{hm_:02d}/{hy} هـ)'
        except Exception:
            pass
    return out


# ---------------- اللغات (ملفات lang/*.json) ----------------
_AR_LETTERS = '؀-ۿݐ-ݿ'
_HAS_AR = re.compile('[' + _AR_LETTERS + ']')


class I18N:
    code = 'ar'
    ui = {}
    data = {}
    _rx = None
    _installed = False

    @classmethod
    def lang_dir(cls):
        return BASE_DIR / 'lang'

    @classmethod
    def available(cls):
        langs = {'ar': 'العربية'}
        try:
            for p in sorted(cls.lang_dir().glob('*.json')):
                try:
                    meta = json.loads(p.read_text(encoding='utf-8')).get('meta', {})
                    langs[p.stem] = meta.get('name', p.stem)
                except Exception:
                    pass
        except Exception:
            pass
        return langs

    @classmethod
    def activate(cls, code):
        code = (code or 'ar').strip() or 'ar'
        cls.code = 'ar'
        cls.ui = {}
        cls.data = {}
        cls._rx = None
        if code != 'ar':
            try:
                doc = json.loads((cls.lang_dir() / (code + '.json')).read_text(encoding='utf-8'))
                ui = {k: v for k, v in doc.get('ui', {}).items() if k and isinstance(v, str)}
                if ui:
                    cls.ui = ui
                    cls.data = {k: v for k, v in doc.get('data', {}).items() if isinstance(v, str)}
                    keys = sorted(ui, key=len, reverse=True)
                    cls._rx = re.compile('(?<![' + _AR_LETTERS + '])(?:' + '|'.join(re.escape(k) for k in keys) + ')(?![' + _AR_LETTERS + '])')
                    cls.code = code
            except Exception as e:
                log_error('language file error: ' + repr(e))
        if cls.code != 'ar':
            cls.install_hooks()

    @classmethod
    def tr(cls, s):
        if cls.code == 'ar' or not isinstance(s, str) or not _HAS_AR.search(s):
            return s
        hit = cls.ui.get(s)
        if hit is not None:
            return hit
        return cls._rx.sub(lambda m: cls.ui[m.group(0)], s) if cls._rx else s

    @classmethod
    def tr_value(cls, v):
        # قيم خلايا الجداول: مطابقة تامة فقط حتى لا تُمسّ أسماء الموظفين والمواد
        if cls.code == 'ar' or not isinstance(v, str):
            return v
        return cls.data.get(v, cls.ui.get(v, v))

    @classmethod
    def install_hooks(cls):
        if cls._installed:
            return
        cls._installed = True
        orig_options = tk.Misc._options

        def _options(self, cnf, kw=None):
            if kw:
                cnf = tk._cnfmerge((cnf, kw))
                kw = None
            else:
                cnf = tk._cnfmerge(cnf)
            if cnf.get('text') is not None and isinstance(cnf['text'], str):
                cnf = dict(cnf)
                cnf['text'] = cls.tr(cnf['text'])
            if cnf.get('label') is not None and isinstance(cnf['label'], str):
                cnf = dict(cnf)
                cnf['label'] = cls.tr(cnf['label'])
            return orig_options(self, cnf, kw)
        tk.Misc._options = _options

        orig_heading = ttk.Treeview.heading

        def heading(self, column, option=None, **kw):
            if isinstance(kw.get('text'), str):
                kw['text'] = cls.tr(kw['text'])
            return orig_heading(self, column, option, **kw)
        ttk.Treeview.heading = heading

        orig_title = tk.Wm.wm_title

        def wm_title(self, string=None):
            return orig_title(self, cls.tr(string) if isinstance(string, str) else string)
        tk.Wm.wm_title = wm_title
        tk.Wm.title = wm_title

        for name in ('showinfo', 'showwarning', 'showerror', 'askyesno', 'askokcancel', 'askquestion', 'askretrycancel'):
            f = getattr(messagebox, name, None)
            if f is None:
                continue

            def mk(f):
                def w(title=None, message=None, **kw):
                    return f(cls.tr(title) if isinstance(title, str) else title, cls.tr(message) if isinstance(message, str) else message, **kw)
                return w
            setattr(messagebox, name, mk(f))
        oa = colorchooser.askcolor

        def askcolor(*a, **kw):
            if isinstance(kw.get('title'), str):
                kw['title'] = cls.tr(kw['title'])
            return oa(*a, **kw)
        colorchooser.askcolor = askcolor
        od = filedialog.askdirectory

        def askdirectory(*a, **kw):
            if isinstance(kw.get('title'), str):
                kw['title'] = cls.tr(kw['title'])
            return od(*a, **kw)
        filedialog.askdirectory = askdirectory


def T(s):
    return I18N.tr(s)


class TrVar(tk.StringVar):
    """متغير نصي يترجم القيمة المعروضة (لعناوين الحالة والملخصات)."""

    def __init__(self, *a, **k):
        v = k.pop('value', None)
        tk.StringVar.__init__(self, *a, **k)
        if v is not None:
            self.set(v)

    def set(self, value):
        return tk.StringVar.set(self, I18N.tr(value) if isinstance(value, str) else value)


# ---------------- الأصوات (اختياري من الإعدادات) ----------------
SOUNDS_ON = False


def _install_sounds():
    def wrap(name, kind):
        f = getattr(messagebox, name)

        def w(*a, **kw):
            if SOUNDS_ON:
                try:
                    if _winsound:
                        _winsound.MessageBeep(kind)
                except Exception:
                    pass
            return f(*a, **kw)
        setattr(messagebox, name, w)
    if _winsound:
        wrap('showinfo', _winsound.MB_ICONASTERISK)
        wrap('showwarning', _winsound.MB_ICONEXCLAMATION)
        wrap('showerror', _winsound.MB_ICONHAND)


_install_sounds()


# ---------------- منع تشغيل نسختين معاً ----------------
def acquire_instance_lock():
    """يعيد (True, handle) عند النجاح، و(False, None) إذا كان البرنامج مفتوحاً، ويتجاوز القفل عند أي مشكلة أخرى."""
    try:
        f = open(DATA_DIR / '.app.lock', 'a+')
    except Exception:
        return True, None
    tries = 12 if os.environ.get('FA_RESTART') else 1
    for _ in range(tries):
        try:
            if os.name == 'nt':
                import msvcrt
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True, f
        except (OSError, IOError):
            time.sleep(0.5)
        except Exception:
            return True, None
    return False, None

# ======================= عناصر واجهة مخصصة (التصميم الحديث) =======================
NAV_BG = '#14263b'      # خلفية الشريط الجانبي
NAV_PANEL = '#1b3049'   # خلفية مجموعات القائمة
NAV_HOVER = '#25405d'
NAV_ACTIVE = '#2d4b6e'


def _shade(color, f):
    # تغميق/تفتيح لون hex بنسبة f
    try:
        c = color.lstrip('#')
        r, g, b = [int(c[i:i + 2], 16) for i in (0, 2, 4)]
        return '#%02x%02x%02x' % tuple(max(0, min(255, int(v * f))) for v in (r, g, b))
    except Exception:
        return color


def _recolor(widget, old, new):
    # يغيّر خلفية كل عنصر داخل widget كانت old إلى new
    try:
        if str(widget.cget('bg')).lower() == str(old).lower():
            widget.configure(bg=new)
    except Exception:
        pass
    for ch in widget.winfo_children():
        _recolor(ch, old, new)


class RoundBox(tk.Canvas):
    # مربع بزوايا مدورة. المحتوى يوضع داخل self.body
    def __init__(self, parent, fill='#ffffff', outline='#dce6ef', outer='#f4f7fb', radius=14, pad=12):
        tk.Canvas.__init__(self, parent, bg=outer, highlightthickness=0, bd=0, width=1, height=20)
        self._fill = fill
        self._outline = outline
        self._r = radius
        self._pad = pad
        self.body = tk.Frame(self, bg=fill)
        self._win = self.create_window(pad, pad, window=self.body, anchor='nw')
        self.bind('<Configure>', self._on_canvas)
        self.body.bind('<Configure>', self._on_body)

    def _on_canvas(self, e):
        self.itemconfigure(self._win, width=max(e.width - 2 * self._pad, 1))
        self._draw(e.width, e.height)

    def _on_body(self, e):
        self.configure(height=e.height + 2 * self._pad)

    def _draw(self, w=None, h=None):
        w = w or self.winfo_width()
        h = h or self.winfo_height()
        self.delete('bg')
        if w < 6 or h < 6:
            return
        r = min(self._r, w // 2, h // 2)
        x0, y0, x1, y1 = 1, 1, w - 2, h - 2
        pts = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1,
               x1 - r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
        self.create_polygon(pts, smooth=True, fill=self._fill, outline=self._outline, tags='bg')
        self.tag_lower('bg')

    def set_fill(self, color):
        old = self._fill
        self._fill = color
        _recolor(self.body, old, color)
        self.body.configure(bg=color)
        self._draw()


class Toggle(tk.Canvas):
    # زر تبديل (ON/OFF) على شكل كبسولة
    def __init__(self, parent, var, on_color, off_color, bg, command=None):
        tk.Canvas.__init__(self, parent, width=46, height=26, bg=bg, highlightthickness=0, bd=0, cursor='hand2')
        self.var = var
        self.on_color = on_color
        self.off_color = off_color
        self.command = command
        self.bind('<Button-1>', self._click)
        self._draw()

    def _click(self, _e=None):
        self.var.set(not bool(self.var.get()))
        self._draw()
        if self.command:
            self.command()

    def _draw(self):
        self.delete('all')
        on = bool(self.var.get())
        col = self.on_color if on else self.off_color
        self.create_oval(1, 1, 25, 25, fill=col, outline=col)
        self.create_oval(21, 1, 45, 25, fill=col, outline=col)
        self.create_rectangle(13, 1, 33, 26, fill=col, outline=col)
        cx = 33 if on else 13
        self.create_oval(cx - 9, 4, cx + 9, 22, fill='#ffffff', outline='')


class Slider(tk.Canvas):
    # شريط تمرير لاختيار رقم صحيح بين lo و hi، القيمة تُخزن كنص في var
    def __init__(self, parent, var, lo, hi, color, track, bg, command=None):
        tk.Canvas.__init__(self, parent, height=30, bg=bg, highlightthickness=0, bd=0, cursor='hand2')
        self.var = var
        self.lo = lo
        self.hi = hi
        self.color = color
        self.track = track
        self.command = command
        self.bind('<Configure>', lambda e: self._draw())
        self.bind('<Button-1>', self._press)
        self.bind('<B1-Motion>', self._press)
        self.bind('<ButtonRelease-1>', self._release)

    def _val(self):
        try:
            return min(max(int(float(self.var.get())), self.lo), self.hi)
        except Exception:
            return self.lo

    def _draw(self):
        self.delete('all')
        w = max(self.winfo_width(), 40)
        pad = 12
        y = 15
        t = (self._val() - self.lo) / float(self.hi - self.lo)
        x = pad + t * (w - 2 * pad)
        self.create_line(pad, y, w - pad, y, width=4, fill=self.track, capstyle='round')
        self.create_line(pad, y, x, y, width=4, fill=self.color, capstyle='round')
        self.create_oval(x - 9, y - 9, x + 9, y + 9, fill=self.color, outline='#ffffff', width=2)

    def _press(self, e):
        w = max(self.winfo_width(), 40)
        pad = 12
        t = min(max((e.x - pad) / float(w - 2 * pad), 0.0), 1.0)
        v = int(round(self.lo + t * (self.hi - self.lo)))
        if str(v) != str(self.var.get()):
            self.var.set(str(v))
        self._draw()

    def _release(self, e):
        self._press(e)
        if self.command:
            self.after(10, self.command)


class Dropdown(tk.Frame):
    # قائمة منسدلة بشكل حديث: النص يمين والسهم يسار
    def __init__(self, parent, var, values, font, fg, field, border, menu_bg, menu_fg, command=None):
        tk.Frame.__init__(self, parent, bg=field, highlightbackground=border, highlightcolor=border,
                          highlightthickness=1, bd=0, cursor='hand2')
        self.var = var
        self.values = list(values)
        self.command = command
        self._font = font
        self._popup_bg = menu_bg
        self._popup_fg = menu_fg
        self._popup = None
        self.arrow = tk.Label(self, text='▾', bg=field, fg='#64748b', font=(font[0], font[1]), cursor='hand2')
        self.arrow.pack(side='left', padx=(10, 0))
        self.lbl = tk.Label(self, text=var.get(), bg=field, fg=fg, font=font, anchor='e', cursor='hand2')
        var.trace_add('write', lambda *_: self.lbl.configure(text=var.get()))
        self.lbl.pack(side='right', fill='x', expand=True, padx=(6, 12), pady=7)
        for w in (self, self.arrow, self.lbl):
            w.bind('<Button-1>', self._open)

    def _open(self, _e=None):
        if self._popup is None:
            self._popup = tk.Menu(self, tearoff=0, font=self._font, bg=self._popup_bg, fg=self._popup_fg)
        self._popup.delete(0, 'end')
        for v in self.values:
            self._popup.add_command(label=v, command=lambda v=v: self._pick(v))
        try:
            self._popup.tk_popup(self.winfo_rootx(), self.winfo_rooty() + self.winfo_height())
        finally:
            self._popup.grab_release()

    def _pick(self, v):
        self.var.set(v)
        if self.command:
            self.after(20, lambda: self.command(v))


class ColorField(tk.Frame):
    # حقل اختيار لون: مربع اللون + سهم
    def __init__(self, parent, var, field, border, command):
        tk.Frame.__init__(self, parent, bg=field, highlightbackground=border, highlightcolor=border,
                          highlightthickness=1, bd=0, cursor='hand2')
        sw = tk.Frame(self, width=30, height=26, highlightbackground='#cbd5e1', highlightthickness=1, cursor='hand2')
        try:
            sw.configure(bg=var.get() or '#ffffff')
        except Exception:
            sw.configure(bg='#ffffff')
        sw.pack(side='left', padx=(10, 4), pady=7)
        arrow = tk.Label(self, text='▾', bg=field, fg='#64748b', cursor='hand2')
        arrow.pack(side='right', padx=(4, 10))
        for w in (self, sw, arrow):
            w.bind('<Button-1>', lambda e: self.after(10, command))


class ThemeTile(tk.Canvas):
    # بطاقة اختيار المظهر (فاتح / داكن ...)
    def __init__(self, parent, text, icon, fill, outline, fg, selected, sel_color, outer, command, font):
        tk.Canvas.__init__(self, parent, height=96, width=96, bg=outer, highlightthickness=0, bd=0, cursor='hand2')
        self._t = (text, icon, fill, outline, fg, selected, sel_color, font)
        self.bind('<Configure>', lambda e: self._draw())
        self.bind('<Button-1>', lambda e: self.after(10, command))

    def _draw(self):
        text, icon, fill, outline, fg, selected, sel, font = self._t
        self.delete('all')
        w = max(self.winfo_width(), 40)
        h = max(self.winfo_height(), 40)
        r = 14
        x0, y0, x1, y1 = 3, 3, w - 4, h - 4
        pts = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1,
               x1 - r, y1, x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
        if selected:
            self.create_polygon(pts, smooth=True, fill=fill, outline=sel, width=3)
        else:
            self.create_polygon(pts, smooth=True, fill=fill, outline=outline, width=1)
        self.create_text(w / 2, h * 0.36, text=icon, fill=fg, font=(font[0], 22))
        self.create_text(w / 2, h * 0.74, text=text, fill=fg, font=font)


class NavItem(tk.Frame):
    # عنصر في القائمة الجانبية: أيقونة ملوّنة + نص
    def __init__(self, parent, name, icon, icon_color, command, bg, fg, font, hover, active_color,
                 own_box=None, solid=False):
        tk.Frame.__init__(self, parent, bg=bg, cursor='hand2')
        self.base = bg
        self.hover = hover
        self.active_color = active_color
        self.own_box = own_box
        self.solid = solid
        self.active = False
        self.alert = False
        self.cur = bg
        self.icon = tk.Label(self, text=icon, bg=bg, fg=icon_color, font=self._icon_font(font), width=2, cursor='hand2')
        self.icon.pack(side='right', padx=(4, 10), pady=4)
        self.text = tk.Label(self, text=name, bg=bg, fg=fg, font=font, anchor='e', cursor='hand2')
        self.text.pack(side='right', fill='x', expand=True, pady=8)
        for w in (self, self.icon, self.text):
            w.bind('<Button-1>', lambda e: command())
            w.bind('<Enter>', self._enter)
            w.bind('<Leave>', self._leave)

    def _paint(self, color):
        if color == self.cur:
            return
        old = self.cur
        self.cur = color
        if self.own_box is not None:
            self.own_box.set_fill(color)
        else:
            _recolor(self, old, color)

    def _target(self):
        if self.alert:
            return '#dc2626'
        if self.active:
            return self.active_color
        return self.base

    def _enter(self, _e=None):
        if not (self.active or self.alert or self.solid):
            self._paint(self.hover)

    def _leave(self, _e=None):
        self._paint(self._target())

    def set_active(self, a):
        self.active = bool(a)
        self._paint(self._target())

    @staticmethod
    def _icon_font(f):
        # أيقونة أكبر من النص بوضوح
        return (f[0], int(f[1]) + 9) + tuple(f[2:])

    def set_font(self, f):
        self.icon.configure(font=self._icon_font(f))
        self.text.configure(font=f)

    def set_alert(self, flag, text=None):
        self.alert = bool(flag)
        if text is not None:
            self.text.configure(text=text)
        self._paint(self._target())

    def set_solid(self, color):
        self.base = color
        self.active_color = color
        self._paint(self._target())



class GridTree(ttk.Treeview):
    # جدول بخطوط عمودية فاصلة بين الأعمدة (مثل الإكسل) بدون خطوط أفقية
    def __init__(self, parent, line_color='#cfd8e3', grid_on=True, **kw):
        ttk.Treeview.__init__(self, parent, **kw)
        self._line_color = line_color
        self._grid_on = grid_on
        self._lines = []
        self._sig = None
        self._pending = False
        self._hh = 30
        self._row_numbers = False
        self._date_fmt = 'dmy'
        self._hijri = False
        for ev in ('<Configure>', '<Map>', '<ButtonRelease-1>', '<<TreeviewSelect>>', '<MouseWheel>'):
            self.bind(ev, self._queue, add='+')

    def insert(self, parent, index, iid=None, **kw):
        vals = kw.get('values')
        if vals is not None and not isinstance(vals, str):
            kw['values'] = [I18N.tr_value(format_date_value(v, self._date_fmt, self._hijri)) for v in vals]
        if self._row_numbers and not parent and 'text' not in kw:
            kw['text'] = str(len(self.get_children('')) + 1)
        return ttk.Treeview.insert(self, parent, index, iid=iid, **kw)

    def set_line_color(self, color):
        self._line_color = color
        self._sig = None
        for ln in self._lines:
            ln.configure(bg=color)
        self._queue()

    def _queue(self, _e=None):
        if self._pending:
            return
        self._pending = True
        self.after(15, self._sync)

    def _columns(self):
        cols = list(self['displaycolumns'])
        if cols == ['#all'] or not cols:
            cols = list(self['columns'])
        return cols

    def _sync(self):
        self._pending = False
        try:
            if not self.winfo_exists():
                return
            kids = self.get_children()
            if kids and self.yview()[0] == 0:
                bb = self.bbox(kids[0])
                if bb:
                    self._hh = max(bb[1], 20)
            xs = []
            x = 0
            if 'tree' in str(self['show']):
                x = int(self.column('#0', 'width'))
                xs.append(x)
            cols = self._columns()
            for c in cols[:-1]:
                x += int(self.column(c, 'width'))
                xs.append(x)
            sig = (tuple(xs), self._hh, self._grid_on, self._line_color)
            if sig == self._sig:
                return
            self._sig = sig
            need = len(xs) if self._grid_on else 0
            while len(self._lines) < need:
                ln = tk.Frame(self, bg=self._line_color, width=1, bd=0, highlightthickness=0)
                ln._custom = True
                self._lines.append(ln)
            for i, ln in enumerate(self._lines):
                if i < need:
                    ln.place(x=xs[i] - 1, y=self._hh, width=1, relheight=1.0, height=-self._hh)
                    ln.configure(bg=self._line_color)
                else:
                    ln.place_forget()
        except Exception:
            pass


class LoginWindow:
    def __init__(self, root, on_success=None):
        self.root=root
        try:
            self.conn=open_db(); self.init_db()
        except sqlite3.Error as e:
            log_error('db open: '+repr(e)); messagebox.showerror('قاعدة البيانات','تعذر فتح قاعدة البيانات:\n'+str(e)+'\n\nإذا كان الملف تالفاً فاستعد آخر نسخة احتياطية من مجلد Backups.'); root.destroy(); raise SystemExit
        I18N.activate(self._lang_code())
        global SOUNDS_ON
        SOUNDS_ON=self.get_setting('sounds')=='1'
        self._known_bad=self._violations()
        self._startup_notes=[]
        self._check_db_health(); self._maybe_reset_password()
        self.font_family=self._font_ok(self.get_setting('font_family') or 'Tahoma'); self.root.title(APP_TITLE); self.root.geometry('430x300'); self.root.resizable(False,False)
        self.build_login()
        for t,m in self._startup_notes: messagebox.showinfo(t,m,parent=self.root)
    def init_db(self):
        self.conn.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS divisions(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS units_list(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS item_units(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,division TEXT,unit_name TEXT,job TEXT,note TEXT,active INTEGER DEFAULT 1)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,unit TEXT,note TEXT,active INTEGER DEFAULT 1)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS stock_receipts(id INTEGER PRIMARY KEY AUTOINCREMENT,item_id INTEGER NOT NULL,qty INTEGER NOT NULL,date TEXT,doc_no TEXT,source TEXT,note TEXT)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,item_id INTEGER NOT NULL,qty INTEGER NOT NULL,from_employee INTEGER,to_employee INTEGER,date TEXT,doc_no TEXT,note TEXT,reason TEXT)')
        self.conn.execute('CREATE TABLE IF NOT EXISTS stock_out(id INTEGER PRIMARY KEY AUTOINCREMENT,item_id INTEGER NOT NULL,qty INTEGER NOT NULL,date TEXT,doc_no TEXT,reason TEXT,extract_to TEXT)')
        # Migration for databases created by older versions.
        cols=[r[1] for r in self.conn.execute('PRAGMA table_info(stock_out)').fetchall()]
        if 'extract_to' not in cols:
            self.conn.execute("ALTER TABLE stock_out ADD COLUMN extract_to TEXT DEFAULT ''")
        for k,v in DEFAULTS.items(): self.conn.execute('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)',(k,v))
        for old in OLD_UPDATE_URLS: self.conn.execute("UPDATE settings SET value=? WHERE key='update_server' AND value=?",(UPDATE_SOURCE_URL,old))
        for name in DEFAULT_DIVISIONS: self.conn.execute('INSERT OR IGNORE INTO divisions(name) VALUES(?)',(name,))
        for name in DEFAULT_UNITS: self.conn.execute('INSERT OR IGNORE INTO units_list(name) VALUES(?)',(name,))
        for name in DEFAULT_CATEGORIES: self.conn.execute('INSERT OR IGNORE INTO categories(name) VALUES(?)',(name,))
        for name in DEFAULT_ITEM_UNITS: self.conn.execute('INSERT OR IGNORE INTO item_units(name) VALUES(?)',(name,))
        self.conn.commit()
    def q(self, sql, params=()):
        """تنفيذ استعلام قاعدة البيانات وإرجاع المؤشر."""
        return self.conn.execute(sql, params)

    def _lang_code(self):
        v=(self.get_setting('language') or '').strip()
        for code,name in I18N.available().items():
            if v==name or v.lower()==code: return code
        return 'ar'

    def _violations(self):
        bad=set()
        for iid,bal in self.conn.execute("SELECT i.id,COALESCE((SELECT SUM(qty) FROM stock_receipts WHERE item_id=i.id),0)-COALESCE((SELECT SUM(qty) FROM stock_out WHERE item_id=i.id),0)-COALESCE((SELECT SUM(qty) FROM transactions WHERE item_id=i.id AND type='توزيع'),0)+COALESCE((SELECT SUM(qty) FROM transactions WHERE item_id=i.id AND type='إرجاع'),0) FROM items i"):
            if (bal or 0)<0: bad.add(('stock',iid,None))
        for iid,eid in self.conn.execute("SELECT item_id,emp FROM (SELECT item_id,to_employee emp,qty d FROM transactions WHERE to_employee IS NOT NULL UNION ALL SELECT item_id,from_employee,-qty FROM transactions WHERE from_employee IS NOT NULL) GROUP BY item_id,emp HAVING SUM(d)<0"):
            bad.add(('held',iid,eid))
        return bad

    def _describe(self,bad):
        lines=[]
        for kind,iid,eid in sorted(bad,key=lambda x:(x[0],x[1],x[2] or 0))[:6]:
            n=self.conn.execute('SELECT name FROM items WHERE id=?',(iid,)).fetchone(); n=n[0] if n else str(iid)
            if kind=='stock': lines.append(f'• رصيد المخزن للمادة «{n}» سيصبح بالسالب')
            else:
                e=self.conn.execute('SELECT name FROM employees WHERE id=?',(eid,)).fetchone(); e=e[0] if e else str(eid)
                lines.append(f'• ذمة الموظف «{e}» من المادة «{n}» ستصبح بالسالب')
        return '\n'.join(lines)

    def commit(self):
        bad=self._violations()-getattr(self,'_known_bad',set())
        if bad:
            self.conn.rollback()
            raise DataIntegrityError('لم تُنفَّذ العملية حفاظاً على صحة السجلات:\n'+self._describe(bad)+'\n\nعدّل الحركات المرتبطة أولاً (إرجاع/تحويل/حذف بالترتيب الصحيح).')
        self.conn.commit()
        self._known_bad=self._violations()

    def _check_db_health(self):
        try:
            r=self.conn.execute('PRAGMA quick_check').fetchone()
            if r and r[0]!='ok':
                shutil.copy2(DB,DATA_DIR/('fixed_assets_corrupt_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.sqlite.bak'))
                self._startup_notes.append(('تنبيه','تم اكتشاف مشكلة في ملف قاعدة البيانات. حُفظت نسخة منه باسم fixed_assets_corrupt_*.bak. يُنصح باستعادة آخر نسخة احتياطية من مجلد Backups.'))
        except Exception as e:
            log_error('health: '+repr(e))

    def _maybe_reset_password(self):
        # استعادة كلمة السر عند النسيان: ضع ملفاً فارغاً باسم RESET_PASSWORD.txt بجانب البرنامج ثم شغّله
        for d in {BASE_DIR,DATA_DIR}:
            f=d/'RESET_PASSWORD.txt'
            try:
                if f.exists():
                    self.conn.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('password_hash',?)",(DEFAULTS['password_hash'],)); self.conn.commit(); f.unlink()
                    self._startup_notes.append(('كلمة السر','تمت إعادة كلمة السر إلى 1234. غيّرها من الإعدادات بعد الدخول.'))
            except Exception as e: log_error('reset pw: '+repr(e))

    def _confirm(self,title,msg):
        if self.get_setting('confirm_delete')=='0': return True
        return messagebox.askyesno(title,msg)

    def _font_ok(self,fam):
        try:
            if fam in set(tkfont.families(self.root)): return fam
        except Exception: pass
        return 'Tahoma'

    def _color(self,key,default):
        v=(self.get_setting(key) or '').strip() or default
        try: self.root.winfo_rgb(v); return v
        except Exception: return default

    def now(self):
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    def get_setting(self,k):
        r=self.conn.execute('SELECT value FROM settings WHERE key=?',(k,)).fetchone(); return r[0] if r else DEFAULTS.get(k,'')
    def build_login(self):
        for w in self.root.winfo_children(): w.destroy()
        self.root.title(APP_TITLE + ' - تسجيل الدخول')
        self.root.configure(bg='#f4f7fb')
        card=tk.Frame(self.root,bg='white',highlightbackground='#dbe5ee',highlightthickness=1,padx=30,pady=18)
        card.pack(fill='both',expand=True,padx=30,pady=22)
        tk.Label(card,text='🔐',font=('Segoe UI Emoji',28),bg='white',fg='#2589ef').pack(pady=(0,2))
        tk.Label(card,text=APP_TITLE,font=(self.font_family,20,'bold'),bg='white',fg='#17283b',anchor='center').pack(fill='x')
        tk.Label(card,text='تسجيل الدخول',font=(self.font_family,13),bg='white',fg='#64748b').pack(pady=(2,12))
        tk.Label(card,text='كلمة السر',font=(self.font_family,11,'bold'),bg='white',fg='#17283b',anchor='e').pack(fill='x')
        self.login_pw=tk.StringVar()
        ent=tk.Entry(card,textvariable=self.login_pw,show='●',justify='right',font=(self.font_family,14),relief='solid',bd=1)
        ent.pack(fill='x',ipady=6,pady=(5,10))
        # زر الدخول واضح وثابت أسفل حقل كلمة السر
        def do_login(event=None):
            value=self.login_pw.get().strip()
            btn.configure(state='disabled') if 'btn' in locals() else None
            self.root.update_idletasks()
            if hashlib.sha256(value.encode('utf-8')).hexdigest()!=self.get_setting('password_hash'):
                messagebox.showerror('خطأ','كلمة السر غير صحيحة',parent=self.root); ent.focus_set(); btn.configure(state='normal'); return
            # الانتقال إلى النظام الرئيسي داخل نفس النافذة، مع إزالة واجهة الدخول بالكامل أولاً
            try: self.root.unbind('<Return>')
            except Exception: pass
            for widget in self.root.winfo_children():
                widget.destroy()
            self.root.title(APP_TITLE)
            self.root.resizable(True, True)
            self.root.minsize(1,1)
            self.root.geometry('1450x900')
            self.root.minsize(1100, 700)
            try:
                self.root.state('zoomed')
            except Exception:
                pass
            self.build()
        btn=tk.Button(card,text='دخول',command=do_login,bg='#2589ef',fg='white',activebackground='#1d73cc',activeforeground='white',relief='flat',bd=0,font=(self.font_family,14,'bold'),cursor='hand2',height=2,highlightthickness=0)
        btn.pack(fill='x',pady=(4,0),ipady=2)
        btn.lift()
        ent.bind('<Return>',do_login)
        self.root.bind('<Return>', do_login)
        ent.focus_set()
        # حجم النافذة يُحسب من محتواها الفعلي (يعمل مع أي تكبير للشاشة أو خط)، فلا يختفي أي حقل أو زر
        self.root.update_idletasks()
        w=max(520,self.root.winfo_reqwidth()+10); h=self.root.winfo_reqheight()+10
        sw,sh=self.root.winfo_screenwidth(),self.root.winfo_screenheight()
        w=min(w,sw-40); h=min(h,sh-80)
        self.root.geometry('%dx%d+%d+%d'%(w,h,max(0,(sw-w)//2),max(0,(sh-h)//2-30)))
        self.root.minsize(w,h)

    def build(self):
        self.theme_name=self.get_setting('theme') or 'فاتح'
        self.font_family=self._font_ok(self.get_setting('font_family') or 'Tahoma')
        try: self.font_size=max(8,min(24,int(self.get_setting('font_size') or 10)))
        except (TypeError,ValueError): self.font_size=10
        self.font_bold=self.get_setting('font_bold')=='1'
        self.font_color=self._color('font_color','#111111')
        self.primary_color=self._color('primary_color','#2589ef')
        self.capsule_color=self._color('capsule_color','#1677ff')
        self.heading_color=self._color('heading_color','#17283b')
        self.background_color=self._color('background_color','#f4f7fb')
        self.language=self.get_setting('language') or 'العربية'
        self.date_format=self.get_setting('date_format') or 'يوم/شهر/سنة'
        self._svars={}; self._wheel_target=None
        # واجهة حديثة: محتوى على اليسار + شريط تنقل داكن على اليمين بمجموعات مدورة.
        self.root.configure(bg='#f4f7fb')
        self.content=tk.Frame(self.root,bg='#f4f7fb')
        self.nav=tk.Frame(self.root,width=292,bg=NAV_BG)
        self.nav.pack(side='right',fill='y'); self.nav.pack_propagate(False)
        self.content.pack(side='left',fill='both',expand=True)

        head=tk.Frame(self.nav,bg=NAV_BG,padx=12,pady=14); head.pack(fill='x')
        tk.Label(head,text=APP_TITLE,font=(self.font_family,16,'bold'),anchor='e',justify='right',bg=NAV_BG,fg='white').pack(fill='x')
        vrow=tk.Frame(head,bg=NAV_BG); vrow.pack(fill='x',pady=(3,9))
        tk.Label(vrow,text=f'الإصدار {APP_VERSION}',font=(self.font_family,9),anchor='e',bg=NAV_BG,fg='#cbd5e1').pack(side='right')
        tk.Label(vrow,text="development : Safa'a Sb.H",font=(self.font_family,9),anchor='w',bg=NAV_BG,fg='#cbd5e1').pack(side='left')
        tk.Frame(head,bg='#2c4055',height=1).pack(fill='x')

        bottom=tk.Frame(self.nav,padx=4,pady=8,bg=NAV_BG); bottom.pack(side='bottom',fill='x')
        nb_holder=tk.Frame(self.nav,bg=NAV_BG); nb_holder.pack(side='top',fill='both',expand=True,padx=4,pady=5)
        self.nav_body=self.scroll_body(nb_holder,0,bg=NAV_BG,plain=True)

        self.sections={}; self.buttons={}; self.current=None
        nf=self._nav_font()
        # زر الرئيسية (أزرق ثابت)
        hb=RoundBox(self.nav_body,fill=self.primary_color,outline=self.primary_color,outer=NAV_BG,radius=12,pad=5)
        hb.pack(fill='x',padx=6,pady=(4,8))
        self.home_button=NavItem(hb.body,'الرئيسية','⌂','#ffffff',lambda:self.show_page('الرئيسية',self.home_tab),self.primary_color,'#ffffff',nf,self.primary_color,self.primary_color,own_box=hb,solid=True)
        self.home_button.pack(fill='x'); self.buttons['الرئيسية']=self.home_button

        self.make_section('البيانات الأساسية','▾', [('الموظفون','👥','#60a5fa',self.employee_tab),('الأصناف والثوابت','▦','#e2e8f0',self.item_tab)])
        self.make_section('المخزن والحركات','▾', [('المخزن','🏢','#fbbf24',self.warehouse_tab),('إدخال المخزن','⇩','#34d399',self.receipt_tab),('توزيع للموظف','♙','#60a5fa',self.issue_tab),('تحويل الذمم','↔','#22d3ee',self.transfer_tab),('إرجاع من موظف','↩','#fb923c',self.return_tab),('إخراج واستهلاك','▣','#f87171',self.out_tab)])
        self.make_section('التقارير','▾', [('ذمم الموظفين','▤','#e2e8f0',self.employee_liability_tab),('سجل الحركات والذمم','▥','#e2e8f0',self.ledger_tab)])

        # الإعدادات والتحديثات: كل واحدة في لوح مدور مستقل
        sb=RoundBox(bottom,fill=NAV_PANEL,outline=NAV_PANEL,outer=NAV_BG,radius=14,pad=5); sb.pack(fill='x',padx=6,pady=(0,6))
        self.settings_bottom=NavItem(sb.body,'الإعدادات','⚙','#e2e8f0',lambda:self.show_page('الإعدادات',self.settings_tab),NAV_PANEL,'#f1f5f9',nf,NAV_HOVER,NAV_ACTIVE,own_box=sb)
        self.settings_bottom.pack(fill='x'); self.buttons['الإعدادات']=self.settings_bottom
        ub=RoundBox(bottom,fill=NAV_PANEL,outline=NAV_PANEL,outer=NAV_BG,radius=14,pad=5); ub.pack(fill='x',padx=6)
        self.updates_bottom=NavItem(ub.body,'التحديثات','☁','#e2e8f0',lambda:self.show_page('التحديثات',self.updates_tab),NAV_PANEL,'#f1f5f9',nf,NAV_HOVER,NAV_ACTIVE,own_box=ub)
        self.updates_bottom.pack(fill='x'); self.buttons['التحديثات']=self.updates_bottom

        # عجلة الفأرة لصفحة الإعدادات (ربط واحد فقط للتطبيق كله)
        self.root.bind_all('<MouseWheel>',self._on_wheel,add='+')
        self.root.bind_all('<Button-4>',self._on_wheel,add='+')
        self.root.bind_all('<Button-5>',self._on_wheel,add='+')
        for _cls in ('Treeview','Listbox','Text','TCombobox'):
            for _seq in ('<MouseWheel>','<Button-4>','<Button-5>'): self.root.bind_class(_cls,_seq,self._on_wheel)
        self._start_update_loop()
        self.show_page('الرئيسية',self.home_tab)
        self.root.after(4000,self._auto_backup)
    def make_section(self,title,arrow,items):
        box=RoundBox(self.nav_body,fill=NAV_PANEL,outline=NAV_PANEL,outer=NAV_BG,radius=14,pad=6)
        box.pack(fill='x',padx=6,pady=(0,8)); var={'open':True}
        nf=self._nav_font()
        def toggle():
            var['open']=not var['open']; hdr.configure(text=('▾  '+title) if var['open'] else ('▸  '+title))
            if var['open']: inner.pack(fill='x')
            else: inner.pack_forget()
        hdr=tk.Button(box.body,text='▾  '+title,command=toggle,anchor='e',relief='flat',bd=0,highlightthickness=0,bg=NAV_PANEL,fg='#cbd5e1',activebackground=NAV_PANEL,activeforeground='white',font=nf,padx=10,pady=6,cursor='hand2'); hdr.pack(fill='x')
        inner=tk.Frame(box.body,bg=NAV_PANEL); inner.pack(fill='x')
        for name,icon,color,cmd in items:
            b=NavItem(inner,name,icon,color,lambda n=name,c=cmd:self.show_page(n,c),NAV_PANEL,'#f1f5f9',nf,NAV_HOVER,NAV_ACTIVE)
            b.pack(fill='x',pady=1); self.buttons[name]=b
        self.sections[title]=(hdr,inner,var)
    def show_page(self,name,creator):
        # إزالة مراجع عناصر الصفحة القديمة حتى لا تحاول refresh الكتابة إلى Treeview تم تدميره.
        stale_attrs=('rccombo','dic','tic','oc','ric','dec','tfc','ttc','rec','e_divc','e_unitc','icatc','iunitc','et','it','rct','dist','trt','ret','ot','lt','held_tree','wh')
        for attr in stale_attrs:
            if hasattr(self,attr):
                try: delattr(self,attr)
                except Exception: pass
        # مغادرة الإعدادات بدون حفظ: إلغاء المعاينة والرجوع للقيم المحفوظة
        if self.current=='الإعدادات': self.load_preferences()
        self._svars={}; self._wheel_target=None
        for w in self.content.winfo_children(): w.destroy()
        self.current=name; creator(); self.apply_theme(); self.refresh()
        for n,b in self.buttons.items():
            try: b.set_active(n==name)
            except Exception: pass
    def page_header(self,parent,title,print_cmd=None):
        h=ttk.Frame(parent); h.pack(fill='x',pady=(0,10)); ttk.Label(h,text=title,font=(self.font_family,18,'bold'),anchor='e').pack(side='right',fill='x',expand=True)
        if print_cmd: ttk.Button(h,text='🖨 طباعة',command=print_cmd).pack(side='left',padx=4)
        return h
    def scroll_body(self,parent,pad=14,bg=None,plain=False):
        # حاوية قابلة للتمرير: تُستخدم لكل الصفحات والنوافذ. عجلة الماوس تحرّك الصفحة كلها.
        try: bgc=bg or self.current_palette()['bg']
        except Exception: bgc=bg or '#f4f7fb'
        cv=tk.Canvas(parent,bg=bgc,highlightthickness=0,bd=0,yscrollincrement=20); cv._page_scroller=True
        sb=ttk.Scrollbar(parent,orient='vertical',command=cv.yview); cv.configure(yscrollcommand=sb.set)
        cv.pack(fill='both',expand=True)
        inner=(tk.Frame(cv,bg=bgc,padx=pad,pady=pad) if plain else ttk.Frame(cv,padding=pad)); wid=cv.create_window((0,0),window=inner,anchor='nw')
        def sync(_e=None):
            try:
                h=cv.winfo_height(); w=cv.winfo_width(); rh=inner.winfo_reqheight()
                full=max(h,rh)
                cv.itemconfigure(wid,width=w,height=full); cv.configure(scrollregion=(0,0,w,full))
                if rh>h+1: sb.place(relx=1.0,rely=0,relheight=1.0,anchor='ne'); sb.lift()
                else: sb.place_forget(); cv.yview_moveto(0)
            except tk.TclError: pass
        cv.bind('<Configure>',sync); inner.bind('<Configure>',lambda e:cv.after_idle(sync))
        inner._canvas=cv
        return inner
    def tabframe(self):
        return self.scroll_body(self.content,14)
    def home_tab(self):
        f=self.tabframe(); self.page_header(f,'الرئيسية')
        ttk.Label(f,text='مرحباً بك في نظام إدارة الثوابت والذمم',font=(self.font_family,22,'bold'),anchor='e',justify='right').pack(fill='x',pady=(20,8))
        ttk.Label(f,text='من هنا يمكنك متابعة الموظفين والمخزن والذمم والحركات والتقارير.',anchor='e',justify='right').pack(fill='x',pady=(0,20))
        cards=ttk.Frame(f); cards.pack(fill='x',pady=5)
        stock=self.q('SELECT COALESCE(SUM(qty),0) FROM stock_receipts').fetchone()[0]-self.q('SELECT COALESCE(SUM(qty),0) FROM stock_out').fetchone()[0]-self.q("SELECT COALESCE(SUM(qty),0) FROM transactions WHERE type='توزيع'").fetchone()[0]+self.q("SELECT COALESCE(SUM(qty),0) FROM transactions WHERE type='إرجاع'").fetchone()[0]
        stats=[('👥 الموظفون',self.q('SELECT COUNT(*) FROM employees WHERE active=1').fetchone()[0]),('📦 الأصناف',self.q('SELECT COUNT(*) FROM items WHERE active=1').fetchone()[0]),('🏢 رصيد المخزن',stock),('🔄 الحركات',self.q('SELECT COUNT(*) FROM transactions').fetchone()[0])]
        for label,value in stats:
            box=ttk.LabelFrame(cards,text=label,padding=18); box.pack(side='right',fill='both',expand=True,padx=6); ttk.Label(box,text=str(value),font=(self.font_family,25,'bold'),anchor='center').pack(fill='both',expand=True)
        recent=ttk.LabelFrame(f,text='آخر الحركات',padding=10); recent.pack(fill='both',expand=True,pady=20)
        t=self.tree(recent,['id','date','type','item','qty','from','to'],['الرقم','التاريخ','الحركة','المادة','الكمية','من','إلى']); t.pack(fill='both',expand=True)
        for r in self.q("SELECT t.id,t.date,t.type,i.name,t.qty,COALESCE(e1.name,''),COALESCE(e2.name,'') FROM transactions t JOIN items i ON i.id=t.item_id LEFT JOIN employees e1 ON e1.id=t.from_employee LEFT JOIN employees e2 ON e2.id=t.to_employee ORDER BY t.id DESC LIMIT 10"): t.insert('','end',values=r)

    def employee_tab(self):
        f=self.tabframe(); self.page_header(f,'الموظفون',lambda:self.print_tree(self.et,'تقرير الموظفين'))
        # شريط البحث والإجراءات: لا تظهر حقول الإدخال إلا عند الضغط على إضافة/تعديل.
        top=ttk.Frame(f); top.pack(fill='x',pady=(0,8))
        self.employee_search=tk.StringVar()
        ttk.Label(top,text='بحث باسم الموظف',anchor='e').pack(side='right',padx=(8,4))
        search_entry=ttk.Entry(top,textvariable=self.employee_search,justify='right',width=42,
                                font=(self.font_family,max(self.font_size+1,11)))
        search_entry.pack(side='right',fill='x',expand=True,padx=4,ipady=4)
        ttk.Button(top,text='🔎 بحث',command=self.load_employees).pack(side='right',padx=3)
        ttk.Button(top,text='🔄 تحديث',command=self.refresh).pack(side='right',padx=3)
        ttk.Button(top,text='➕ إضافة موظف',command=self.add_employee).pack(side='right',padx=3)
        ttk.Button(top,text='✏ تعديل',command=self.edit_employee).pack(side='right',padx=3)
        ttk.Button(top,text='🗑 حذف',command=self.delete_employee).pack(side='right',padx=3)
        search_entry.bind('<Return>',lambda e:self.load_employees())
        search_entry.bind('<KeyRelease>',lambda e:self.load_employees())
        self.et=self.tree(f,['id','name','division','unit_name','job','note'],['الرقم','اسم الموظف','الشعبة','الوحدة','الوظيفة','الملاحظات'])
        self.et.pack(fill='both',expand=True); self.et.bind('<<TreeviewSelect>>',self.employee_selected); self.et.bind('<Double-1>', self.employee_double_click)
        self.load_employees()

    def employee_dialog(self, employee_id=None):
        win=tk.Toplevel(self.root); win.title('إضافة موظف' if employee_id is None else 'تعديل موظف')
        win.geometry('650x430'); win.minsize(600,390); win.transient(self.root); win.grab_set()
        win.configure(bg=self.root.cget('bg'))
        outer=self.scroll_body(win,18)
        title=ttk.Label(outer,text=('إضافة موظف جديد' if employee_id is None else 'تعديل بيانات الموظف'),anchor='e',font=(self.font_family,16,'bold'))
        title.pack(fill='x',pady=(0,16))
        name=tk.StringVar(); division=tk.StringVar(); unit=tk.StringVar(); job=tk.StringVar(); note=tk.StringVar()
        if employee_id is not None:
            r=self.q('SELECT name,division,unit_name,job,note FROM employees WHERE id=?',(employee_id,)).fetchone()
            if r: name.set(r[0] or ''); division.set(r[1] or ''); unit.set(r[2] or ''); job.set(r[3] or ''); note.set(r[4] or '')
        # الاسم بخانة كبيرة وواضحة
        r1=ttk.Frame(outer); r1.pack(fill='x',pady=5)
        ttk.Label(r1,text='اسم الموظف',width=15,anchor='e').pack(side='right',padx=5)
        ttk.Entry(r1,textvariable=name,justify='right',font=(self.font_family,max(self.font_size+3,14),'bold')).pack(side='right',fill='x',expand=True,ipady=8)
        r2=ttk.Frame(outer); r2.pack(fill='x',pady=5)
        ttk.Label(r2,text='الشعبة',width=15,anchor='e').pack(side='right',padx=5)
        divc=ttk.Combobox(r2,textvariable=division,state='readonly',justify='right',font=(self.font_family,self.font_size+1))
        divc.pack(side='right',fill='x',expand=True,padx=3,ipady=3); divc['values']=[r[0] for r in self.q('SELECT name FROM divisions ORDER BY name')]
        r3=ttk.Frame(outer); r3.pack(fill='x',pady=5)
        ttk.Label(r3,text='الوحدة',width=15,anchor='e').pack(side='right',padx=5)
        unitc=ttk.Combobox(r3,textvariable=unit,state='readonly',justify='right',font=(self.font_family,self.font_size+1))
        unitc.pack(side='right',fill='x',expand=True,padx=3,ipady=3); unitc['values']=[r[0] for r in self.q('SELECT name FROM units_list ORDER BY name')]
        r4=ttk.Frame(outer); r4.pack(fill='x',pady=5)
        ttk.Label(r4,text='الوظيفة',width=15,anchor='e').pack(side='right',padx=5)
        ttk.Entry(r4,textvariable=job,justify='right').pack(side='right',fill='x',expand=True,ipady=5)
        r5=ttk.Frame(outer); r5.pack(fill='x',pady=5)
        ttk.Label(r5,text='الملاحظات',width=15,anchor='e').pack(side='right',padx=5)
        ttk.Entry(r5,textvariable=note,justify='right').pack(side='right',fill='x',expand=True,ipady=5)
        buttons=ttk.Frame(outer); buttons.pack(fill='x',pady=(18,0))
        def save():
            if not name.get().strip():
                return messagebox.showwarning('تنبيه','اكتب اسم الموظف',parent=win)
            if employee_id is None:
                self.q('INSERT INTO employees(name,division,unit_name,job,note) VALUES(?,?,?,?,?)',(name.get().strip(),division.get(),unit.get(),job.get().strip(),note.get().strip()))
            else:
                self.q('UPDATE employees SET name=?,division=?,unit_name=?,job=?,note=? WHERE id=?',(name.get().strip(),division.get(),unit.get(),job.get().strip(),note.get().strip(),employee_id))
            self.commit(); win.destroy(); self.refresh()
        ttk.Button(buttons,text='💾 حفظ',command=save).pack(side='right',padx=4)
        ttk.Button(buttons,text='إلغاء',command=win.destroy).pack(side='right',padx=4)
        win.bind('<Return>',lambda e:save())
        win.after(80,lambda:outer.winfo_children()[1].winfo_children()[-1].focus_set())

    def load_employees(self):
        if not hasattr(self,'et'): return
        self.clear(self.et)
        s='%'+getattr(self,'employee_search',tk.StringVar()).get().strip()+'%'
        rows=self.q('SELECT id,name,division,unit_name,job,note FROM employees WHERE active=1 AND name LIKE ? ORDER BY name',(s,))
        for r in rows: self.et.insert('','end',values=r)

    def item_tab(self):
        f=self.tabframe(); self.page_header(f,'الأصناف والثوابت',lambda:self.print_tree(self.it,'تقرير الأصناف والثوابت'))
        top=ttk.Frame(f); top.pack(fill='x',pady=(0,8))
        self.item_search=tk.StringVar()
        ttk.Label(top,text='البحث عن مادة',anchor='e').pack(side='right',padx=(8,4))
        search_entry=ttk.Entry(top,textvariable=self.item_search,justify='right',width=42,
                                font=(self.font_family,max(self.font_size+1,11)))
        search_entry.pack(side='right',fill='x',expand=True,padx=4,ipady=4)
        ttk.Button(top,text='🔎 بحث',command=self.load_items).pack(side='right',padx=3)
        ttk.Button(top,text='🔄 تحديث',command=self.refresh).pack(side='right',padx=3)
        ttk.Button(top,text='➕ إضافة مادة',command=self.add_item).pack(side='right',padx=3)
        ttk.Button(top,text='✏ تعديل',command=self.edit_item).pack(side='right',padx=3)
        ttk.Button(top,text='🗑 حذف',command=self.delete_item).pack(side='right',padx=3)
        search_entry.bind('<Return>',lambda e:self.load_items())
        search_entry.bind('<KeyRelease>',lambda e:self.load_items())
        self.it=self.tree(f,['id','name','category','unit','stock','held','total','note'],['الرقم','المادة','التصنيف','الوحدة','رصيد المخزن','عند الموظفين','الكمية الكلية','الملاحظات'])
        self.it.pack(fill='both',expand=True); self.it.bind('<<TreeviewSelect>>',self.item_selected); self.it.bind('<Double-1>',self.item_double_click)
        self.load_items()

    def norm_text(self, value):
        return ' '.join(str(value or '').strip().split()).casefold()

    def item_duplicate(self, name, category, unit, exclude_id=None):
        n=self.norm_text(name)
        rows=self.q('SELECT id,name,category,unit FROM items WHERE active=1').fetchall()
        for rid,rn,rc,ru in rows:
            if exclude_id is not None and int(rid)==int(exclude_id):
                continue
            if self.norm_text(rn)==n:
                return f'مادة باسم «{rn}» موجودة مسبقًا.'
            # منع التكرار عندما تكون تفاصيل الصنف نفسها بالكامل، مع السماح بأصناف مختلفة ضمن نفس التصنيف والوحدة.
            # (مثل كرسي وطاولة كلاهما ضمن تصنيف الأثاث ووحدة قطعة).
        return None

    def item_dialog(self, item_id=None):
        win=tk.Toplevel(self.root); win.title('إضافة مادة' if item_id is None else 'تعديل مادة')
        win.geometry('700x430'); win.minsize(620,390); win.transient(self.root); win.grab_set(); win.configure(bg=self.root.cget('bg'))
        outer=self.scroll_body(win,18)
        ttk.Label(outer,text=('إضافة مادة جديدة' if item_id is None else 'تعديل بيانات المادة'),anchor='e',font=(self.font_family,16,'bold')).pack(fill='x',pady=(0,16))
        name=tk.StringVar(); category=tk.StringVar(); unit=tk.StringVar(); note=tk.StringVar(); qty=tk.StringVar(value='1')
        if item_id is not None:
            r=self.q('SELECT name,category,unit,note FROM items WHERE id=?',(item_id,)).fetchone()
            if r: name.set(r[0] or ''); category.set(r[1] or ''); unit.set(r[2] or ''); note.set(r[3] or ''); qty.set(str(self.stock(item_id)))
        cats=[r[0] for r in self.q('SELECT name FROM categories ORDER BY name')]
        units=[r[0] for r in self.q('SELECT name FROM item_units ORDER BY name')]
        if not category.get() and cats: category.set(cats[0])
        if not unit.get() and units: unit.set(units[0])

        r1=ttk.Frame(outer); r1.pack(fill='x',pady=7)
        ttk.Label(r1,text='اسم المادة',width=15,anchor='e').pack(side='right',padx=5)
        name_entry=ttk.Entry(r1,textvariable=name,justify='right',font=(self.font_family,max(self.font_size+3,14),'bold'))
        name_entry.pack(side='right',fill='x',expand=True,ipady=9)

        r2=ttk.Frame(outer); r2.pack(fill='x',pady=7)
        right=ttk.Frame(r2); right.pack(side='right',fill='x',expand=True,padx=(0,6))
        ttk.Label(right,text='التصنيف',width=12,anchor='e').pack(side='right',padx=5)
        catc=ttk.Combobox(right,textvariable=category,values=cats,state='readonly',justify='right',font=(self.font_family,self.font_size+1))
        catc.pack(side='right',fill='x',expand=True,ipady=3)
        left=ttk.Frame(r2); left.pack(side='right',fill='x',expand=True,padx=(6,0))
        ttk.Label(left,text='الوحدة',width=12,anchor='e').pack(side='right',padx=5)
        unitc=ttk.Combobox(left,textvariable=unit,values=units,state='readonly',justify='right',font=(self.font_family,self.font_size+1))
        unitc.pack(side='right',fill='x',expand=True,ipady=3)

        r3=ttk.Frame(outer); r3.pack(fill='x',pady=7)
        ttk.Label(r3,text='🔢 العدد',width=15,anchor='e').pack(side='right',padx=5)
        ttk.Entry(r3,textvariable=qty,justify='right',width=14,font=(self.font_family,max(self.font_size+2,12),'bold')).pack(side='right',ipady=6)

        r4=ttk.Frame(outer); r4.pack(fill='x',pady=7)
        ttk.Label(r4,text='الملاحظات',width=15,anchor='e').pack(side='right',padx=5)
        ttk.Entry(r4,textvariable=note,justify='right').pack(side='right',fill='x',expand=True,ipady=5)

        buttons=ttk.Frame(outer); buttons.pack(fill='x',pady=(18,0))
        def save():
            if not name.get().strip(): return messagebox.showwarning('تنبيه','اكتب اسم المادة',parent=win)
            if not category.get(): return messagebox.showwarning('تنبيه','اختر التصنيف',parent=win)
            if not unit.get(): return messagebox.showwarning('تنبيه','اختر الوحدة',parent=win)
            try:
                q0=int(qty.get().strip() or '0')
                if q0 < 1: raise ValueError
            except ValueError:
                return messagebox.showwarning('تنبيه','أدخل عددًا صحيحًا أكبر من صفر',parent=win)
            dup=self.item_duplicate(name.get(),category.get(),unit.get(),item_id)
            if dup:
                return messagebox.showwarning('منع التكرار',dup,parent=win)
            if item_id is None:
                self.q('INSERT INTO items(name,category,unit,note) VALUES(?,?,?,?)',(name.get().strip(),category.get(),unit.get(),note.get().strip()))
                new_id=self.q('SELECT last_insert_rowid()').fetchone()[0]
                # العدد عند إنشاء المادة يمثل الرصيد الافتتاحي، ويسجل كإدخال مخزني حتى يبقى السجل المحاسبي صحيحًا.
                self.q('INSERT INTO stock_receipts(item_id,qty,date,doc_no,source,note) VALUES(?,?,?,?,?,?)',(new_id,q0,datetime.now().strftime('%Y-%m-%d %H:%M'),'افتتاحي','إضافة مادة','رصيد افتتاحي عند إنشاء المادة'))
            else:
                # عند تعديل العدد، لا نغيّر بطاقة الصنف فقط؛ نسجل فرق العدد كحركة مخزنية
                # حتى يبقى الرصيد وسجل الحركات متطابقين. مثال: 2 -> 6 يسجل +4.
                old_qty=self.stock(item_id)
                self.q('UPDATE items SET name=?,category=?,unit=?,note=? WHERE id=?',(name.get().strip(),category.get(),unit.get(),note.get().strip(),item_id))
                diff=q0-old_qty
                if diff>0:
                    self.q('INSERT INTO stock_receipts(item_id,qty,date,doc_no,source,note) VALUES(?,?,?,?,?,?)',(item_id,diff,self.now(),'تعديل','تعديل بيانات المادة',f'زيادة الرصيد من {old_qty} إلى {q0}'))
                elif diff<0:
                    self.q('INSERT INTO stock_out(item_id,qty,date,doc_no,reason,extract_to) VALUES(?,?,?,?,?,?)',(item_id,-diff,self.now(),'تعديل','تعديل رصيد المادة','تعديل بيانات المادة'))
            self.commit(); win.destroy(); self.load_items(); self.refresh()
        ttk.Button(buttons,text='💾 حفظ',command=save).pack(side='right',padx=4)
        ttk.Button(buttons,text='إلغاء',command=win.destroy).pack(side='right',padx=4)
        win.bind('<Return>',lambda e:save())
        win.after(80,name_entry.focus_set)

    def movement_form(self,parent):
        return ttk.LabelFrame(parent,text='بيانات الحركة',padding=10)
    def movement_search_row(self,parent,label,var,command):
        row=ttk.Frame(parent); row.pack(fill='x',pady=(0,8))
        ttk.Label(row,text=label,anchor='e').pack(side='right',padx=(8,4))
        e=ttk.Entry(row,textvariable=var,justify='right',font=(self.font_family,max(self.font_size+1,11)))
        e.pack(side='right',fill='x',expand=True,padx=4,ipady=4)
        ttk.Button(row,text='🔎 بحث',command=command).pack(side='right',padx=3)
        ttk.Button(row,text='🔄 تحديث',command=self.refresh).pack(side='right',padx=3)
        return e

    def warehouse_tab(self):
        f=self.tabframe(); self.page_header(f,'المخزن',lambda:self.print_tree(self.wh,'تقرير موجودات المخزن'))
        self.wh_search=tk.StringVar(); self.wh_zero=tk.BooleanVar(value=False)
        top=ttk.Frame(f); top.pack(fill='x',pady=(0,8))
        ttk.Label(top,text='بحث باسم المادة',anchor='e').pack(side='right',padx=(8,4))
        e=ttk.Entry(top,textvariable=self.wh_search,justify='right',font=(self.font_family,max(self.font_size+1,11))); e.pack(side='right',fill='x',expand=True,padx=4,ipady=4)
        e.bind('<KeyRelease>',lambda ev:self.load_warehouse())
        ttk.Button(top,text='🔄 تحديث',command=self.refresh).pack(side='right',padx=3)
        ttk.Checkbutton(top,text='إظهار المواد التي رصيدها صفر',variable=self.wh_zero,command=self.load_warehouse).pack(side='right',padx=10)
        self.wh_summary=TrVar()
        ttk.Label(f,textvariable=self.wh_summary,anchor='e',justify='right').pack(fill='x',pady=(0,6))
        self.wh=self.tree(f,['id','item','category','unit','stock','received','returned','issued','consumed','last','details'],['الرقم','المادة','التصنيف','الوحدة','الرصيد بالمخزن','إدخال جديد','إرجاع مخزني','موزّع للموظفين','مُخرَج','آخر حركة','التفاصيل'])
        self.wh.pack(fill='both',expand=True); self.wh.bind('<Double-1>',self.warehouse_double_click)
        ttk.Label(f,text='انقر مرتين على أي مادة لعرض كل حركاتها مع المخزن (إدخال جديد، إرجاع مخزني، توزيع، إخراج).',anchor='e',justify='right').pack(fill='x',pady=(6,0))
        self.load_warehouse()

    def _wh_last_move(self,item_id):
        r=self.q("SELECT date,label FROM ("
                 "SELECT date,'إدخال جديد' label,id FROM stock_receipts WHERE item_id=? "
                 "UNION ALL SELECT date,'إرجاع مخزني',id FROM transactions WHERE type='إرجاع' AND item_id=? "
                 "UNION ALL SELECT date,'توزيع للموظف',id FROM transactions WHERE type='توزيع' AND item_id=? "
                 "UNION ALL SELECT date,'إخراج واستهلاك',id FROM stock_out WHERE item_id=?) "
                 "ORDER BY date DESC,id DESC LIMIT 1",(item_id,item_id,item_id,item_id)).fetchone()
        return r if r else ('','—')

    def load_warehouse(self):
        if not hasattr(self,'wh'): return
        self.clear(self.wh)
        s='%'+self.wh_search.get().strip()+'%'
        rows=self.q("SELECT i.id,i.name,COALESCE(i.category,''),COALESCE(i.unit,''),"
                    "COALESCE((SELECT SUM(qty) FROM stock_receipts WHERE item_id=i.id),0),"
                    "COALESCE((SELECT SUM(qty) FROM transactions WHERE type='إرجاع' AND item_id=i.id),0),"
                    "COALESCE((SELECT SUM(qty) FROM transactions WHERE type='توزيع' AND item_id=i.id),0),"
                    "COALESCE((SELECT SUM(qty) FROM stock_out WHERE item_id=i.id),0) "
                    "FROM items i WHERE i.active=1 AND i.name LIKE ? ORDER BY i.name",(s,)).fetchall()
        shown=0; total=0
        for iid,name,cat,unit,rin,rret,rdist,rout in rows:
            bal=rin+rret-rdist-rout
            if bal<=0 and not self.wh_zero.get(): continue
            d,label=self._wh_last_move(iid)
            parts=[]
            if rin: parts.append(f'إدخال جديد {rin}')
            if rret: parts.append(f'إرجاع مخزني {rret}')
            if rdist: parts.append(f'موزّع {rdist}')
            if rout: parts.append(f'مُخرَج {rout}')
            self.wh.insert('','end',values=(iid,name,cat,unit,bal,rin,rret,rdist,rout,str(d)[:10],I18N.tr('  |  '.join(parts))))
            shown+=1; total+=max(bal,0)
        self.wh_summary.set(f'عدد المواد الموجودة بالمخزن: {shown}    •    مجموع الكميات: {total}')
        self.wh._queue()

    def warehouse_double_click(self,event=None):
        sel=self.wh.selection()
        if not sel: return
        iid=self.wh.set(sel[0],'id'); name=self.wh.set(sel[0],'item')
        win=tk.Toplevel(self.root); win.title('حركات المخزن - '+str(name)); win.geometry('900x480'); win.transient(self.root)
        box=self.scroll_body(win,14)
        ttk.Label(box,text='حركات المخزن للمادة: '+str(name),anchor='e',font=(self.font_family,15,'bold')).pack(fill='x',pady=(0,10))
        t=self.tree(box,['date','type','qty','party','doc','note'],['التاريخ','نوع الحركة','الكمية','الموظف / الجهة','المستند','الملاحظة']); t.pack(fill='both',expand=True)
        sql=("SELECT date,'إدخال جديد','+'||qty,COALESCE(source,''),COALESCE(doc_no,''),COALESCE(note,'') FROM stock_receipts WHERE item_id=? "
             "UNION ALL SELECT t.date,'توزيع للموظف','-'||t.qty,COALESCE(e.name,''),COALESCE(t.doc_no,''),COALESCE(t.note,'') FROM transactions t LEFT JOIN employees e ON e.id=t.to_employee WHERE t.type='توزيع' AND t.item_id=? "
             "UNION ALL SELECT t.date,'إرجاع مخزني','+'||t.qty,COALESCE(e.name,''),COALESCE(t.doc_no,''),COALESCE(t.reason,'') FROM transactions t LEFT JOIN employees e ON e.id=t.from_employee WHERE t.type='إرجاع' AND t.item_id=? "
             "UNION ALL SELECT date,'إخراج واستهلاك','-'||qty,COALESCE(extract_to,''),COALESCE(doc_no,''),COALESCE(reason,'') FROM stock_out WHERE item_id=? "
             "ORDER BY 1 DESC")
        for r in self.q(sql,(iid,iid,iid,iid)): t.insert('','end',values=r)

    def receipt_tab(self):
        f=self.tabframe(); self.page_header(f,'إدخال إلى المخزن',lambda:self.print_tree(self.rct,'تقرير إدخالات المخزن'))
        self.rcsearch=tk.StringVar()
        self.movement_search_row(f,'البحث عن مادة',self.rcsearch,lambda:self.load_movement_tree(self.rct,'receipt'))
        bar=ttk.Frame(f); bar.pack(fill='x',pady=4)
        ttk.Button(bar,text='📥 إدخال مادة',command=lambda:self.receipt_dialog()).pack(side='right',padx=3)
        ttk.Button(bar,text='✏ تعديل',command=self.edit_receipt).pack(side='right',padx=3)
        ttk.Button(bar,text='🗑 حذف',command=self.delete_receipt).pack(side='right',padx=3)
        self.rct=self.tree(f,['id','date','item','qty','doc','source','note'],['الرقم','التاريخ','المادة','الكمية','المستند','المصدر','الملاحظة']); self.rct.pack(fill='both',expand=True)
        self.load_movement_tree(self.rct,'receipt')

    def receipt_dialog(self, receipt_id=None):
        win=tk.Toplevel(self.root); win.title('إدخال مادة إلى المخزن' if receipt_id is None else 'تعديل إدخال مخزني'); win.geometry('720x470'); win.transient(self.root); win.grab_set()
        outer=self.scroll_body(win,18)
        ttk.Label(outer,text='إدخال مادة إلى المخزن',anchor='e',font=(self.font_family,16,'bold')).pack(fill='x',pady=(0,14))
        search=tk.StringVar(); item=tk.StringVar(); qty=tk.StringVar(value='1'); doc=tk.StringVar(); src=tk.StringVar(); note=tk.StringVar()
        old_item=None
        if receipt_id:
            old_item=self.q('SELECT item_id,qty,doc_no,source,note FROM stock_receipts WHERE id=?',(receipt_id,)).fetchone()
            if old_item: item.set(f'{old_item[0]} - '+self.q('SELECT name FROM items WHERE id=?',(old_item[0],)).fetchone()[0]); qty.set(old_item[1]); doc.set(old_item[2] or ''); src.set(old_item[3] or ''); note.set(old_item[4] or '')
        ttk.Label(outer,text='🔎 البحث عن مادة',anchor='e').pack(fill='x')
        se=ttk.Entry(outer,textvariable=search,justify='right',font=(self.font_family,max(self.font_size+1,11))); se.pack(fill='x',ipady=6,pady=4)
        combo=ttk.Combobox(outer,textvariable=item,state='readonly',justify='right',font=(self.font_family,self.font_size+1)); combo.pack(fill='x',ipady=5,pady=4)
        ttk.Label(outer,text='اختر المادة من النتائج',anchor='e').pack(fill='x',pady=(2,0))
        def load(*_):
            # إعادة بناء النتائج مع كل حرف، ومسح الاختيار القديم حتى لا تبقى مادة غير ظاهرة.
            item.set('')
            pat='%'+search.get().strip()+'%'
            rows=self.q('SELECT id,name,category,unit FROM items WHERE active=1 AND (name LIKE ? OR category LIKE ?) ORDER BY name',(pat,pat)).fetchall()
            vals=[f'{r[0]} - {r[1]}' for r in rows]
            combo['values']=vals
            if vals:
                combo.current(0)
            else:
                combo.set('')
        search.trace_add('write', load)
        combo.bind('<<ComboboxSelected>>', lambda e: item.set(combo.get()))
        load()
        rr=ttk.Frame(outer); rr.pack(fill='x',pady=8)
        for lab,var,w in [('🔢 العدد',qty,10),('رقم المستند',doc,16),('المصدر',src,18),('الملاحظات',note,24)]:
            cell=ttk.Frame(rr); cell.pack(side='right',fill='x',expand=True,padx=3)
            ttk.Label(cell,text=lab,anchor='e').pack(fill='x')
            ttk.Entry(cell,textvariable=var,width=w,justify='center').pack(fill='x',ipady=4)
        def save():
            try:i=self.parse(item.get()); q=self.qty(qty.get())
            except Exception as e:return messagebox.showerror('خطأ',str(e),parent=win)
            if not i:return messagebox.showwarning('تنبيه','اختر المادة',parent=win)
            if receipt_id:self.q('UPDATE stock_receipts SET item_id=?,qty=?,doc_no=?,source=?,note=? WHERE id=?',(i,q,doc.get(),src.get(),note.get(),receipt_id))
            else:self.q('INSERT INTO stock_receipts(item_id,qty,date,doc_no,source,note) VALUES(?,?,?,?,?,?)',(i,q,self.now(),doc.get(),src.get(),note.get()))
            self.commit(); win.destroy(); self.refresh()
        b=ttk.Frame(outer); b.pack(fill='x',pady=15); ttk.Button(b,text='💾 حفظ',command=save).pack(side='right',padx=4); ttk.Button(b,text='إلغاء',command=win.destroy).pack(side='right',padx=4); win.after(80,se.focus_set)

    def issue_tab(self):
        f=self.tabframe(); self.page_header(f,'توزيع المواد للموظفين',lambda:self.print_tree(self.dist,'تقرير توزيع المواد'))
        self.disearch=tk.StringVar(); self.movement_search_row(f,'البحث عن مادة',self.disearch,lambda:self.load_movement_tree(self.dist,'dist'))
        bar=ttk.Frame(f); bar.pack(fill='x',pady=4); ttk.Button(bar,text='📋 توزيع مادة',command=lambda:self.distribution_dialog()).pack(side='right',padx=3); ttk.Button(bar,text='✏ تعديل',command=self.edit_distribution).pack(side='right',padx=3); ttk.Button(bar,text='🗑 حذف',command=self.delete_distribution).pack(side='right',padx=3)
        self.dist=self.tree(f,['id','date','item','qty','employee','doc','note'],['الرقم','التاريخ','المادة','الكمية','الموظف','المستند','الملاحظة']); self.dist.pack(fill='both',expand=True); self.load_movement_tree(self.dist,'dist')

    def distribution_dialog(self, tid=None):
        win=tk.Toplevel(self.root); win.title('توزيع مادة للموظف'); win.geometry('720x470'); win.transient(self.root); win.grab_set(); outer=self.scroll_body(win,18)
        ttk.Label(outer,text='توزيع مادة للموظف',font=(self.font_family,16,'bold'),anchor='e').pack(fill='x',pady=(0,14))
        search=tk.StringVar(); item=tk.StringVar(); emp=tk.StringVar(); qty=tk.StringVar(value='1'); doc=tk.StringVar(); note=tk.StringVar(); old=None
        if tid:
            old=self.q('SELECT item_id,to_employee,qty,doc_no,note FROM transactions WHERE id=?',(tid,)).fetchone()
            if old:item.set(f"{old[0]} - {self.q('SELECT name FROM items WHERE id=?',(old[0],)).fetchone()[0]}"); emp.set(f"{old[1]} - {self.q('SELECT name FROM employees WHERE id=?',(old[1],)).fetchone()[0]}"); qty.set(old[2]); doc.set(old[3] or ''); note.set(old[4] or '')
        ttk.Label(outer,text='البحث عن مادة',anchor='e').pack(fill='x'); se=ttk.Entry(outer,textvariable=search,justify='right'); se.pack(fill='x',ipady=5,pady=4); combo=ttk.Combobox(outer,textvariable=item,state='readonly',justify='right'); combo.pack(fill='x',ipady=4)
        def load_items():
            pat='%'+search.get().strip()+'%'; rows=self.q('SELECT id,name FROM items WHERE active=1 AND name LIKE ? ORDER BY name',(pat,)).fetchall(); combo['values']=[f'{i} - {n}' for i,n in rows]
            if not item.get() and rows:item.set(combo['values'][0])
        se.bind('<KeyRelease>',lambda e:load_items()); load_items()
        ttk.Label(outer,text='الموظف',anchor='e').pack(fill='x',pady=(9,0)); ec=ttk.Combobox(outer,textvariable=emp,state='readonly',justify='right'); ec.pack(fill='x',ipady=4); er=self.ids('employees'); ec['values']=[f'{i} - {n}' for i,n in er]
        rr=ttk.Frame(outer); rr.pack(fill='x',pady=8)
        for lab,var,w in [('🔢 العدد',qty,10),('المستند',doc,16),('الملاحظات',note,24)]:ttk.Label(rr,text=lab).pack(side='right',padx=4);ttk.Entry(rr,textvariable=var,width=w,justify='right').pack(side='right',padx=4)
        def save():
            try:i=self.parse(item.get()); e=self.parse(emp.get()); q=self.qty(qty.get())
            except Exception as x:return messagebox.showerror('خطأ',str(x),parent=win)
            if not i or not e:return messagebox.showwarning('تنبيه','اختر المادة والموظف',parent=win)
            available=self.stock(i)+(old[2] if old else 0)
            if available<q:return messagebox.showerror('خطأ','الكمية غير متوفرة في المخزن',parent=win)
            if tid:self.q('UPDATE transactions SET item_id=?,to_employee=?,qty=?,doc_no=?,note=? WHERE id=?',(i,e,q,doc.get(),note.get(),tid))
            else:self.q("INSERT INTO transactions(type,item_id,qty,to_employee,date,doc_no,note) VALUES('توزيع',?,?,?,?,?,?)",(i,q,e,self.now(),doc.get(),note.get()))
            self.commit();win.destroy();self.refresh()
        b=ttk.Frame(outer);b.pack(fill='x',pady=14);ttk.Button(b,text='💾 حفظ',command=save).pack(side='right',padx=4);ttk.Button(b,text='إلغاء',command=win.destroy).pack(side='right',padx=4)

    def transfer_tab(self):
        f=self.tabframe(); self.page_header(f,'تحويل الذمم',lambda:self.print_tree(self.trt,'تقرير تحويل الذمم'))
        self.trsearch=tk.StringVar(); self.movement_search_row(f,'البحث عن مادة',self.trsearch,lambda:self.load_movement_tree(self.trt,'transfer'))
        bar=ttk.Frame(f);bar.pack(fill='x',pady=4);ttk.Button(bar,text='🔄 تحويل ذمة',command=lambda:self.transfer_dialog()).pack(side='right',padx=3);ttk.Button(bar,text='✏ تعديل',command=self.edit_transfer).pack(side='right',padx=3);ttk.Button(bar,text='🗑 حذف',command=self.delete_transfer).pack(side='right',padx=3)
        self.trt=self.tree(f,['id','date','item','qty','from','to','doc','reason'],['الرقم','التاريخ','المادة','الكمية','من','إلى','المستند','السبب']);self.trt.pack(fill='both',expand=True);self.trt.bind('<<TreeviewSelect>>',self.transfer_selected);self.load_movement_tree(self.trt,'transfer')

    def transfer_dialog(self, tid=None):
        win=tk.Toplevel(self.root);win.title('تحويل الذمة');win.geometry('720x500');win.transient(self.root);win.grab_set();outer=self.scroll_body(win,18);ttk.Label(outer,text='تحويل مادة من موظف إلى موظف',font=(self.font_family,16,'bold'),anchor='e').pack(fill='x',pady=(0,14))
        search=tk.StringVar();item=tk.StringVar();src=tk.StringVar();dst=tk.StringVar();qty=tk.StringVar(value='1');doc=tk.StringVar();reason=tk.StringVar();extract_to=tk.StringVar();old=None
        if tid:
            old=self.q('SELECT item_id,from_employee,to_employee,qty,doc_no,reason FROM transactions WHERE id=?',(tid,)).fetchone()
            if old:item.set(f"{old[0]} - {self.q('SELECT name FROM items WHERE id=?',(old[0],)).fetchone()[0]}");src.set(f"{old[1]} - {self.q('SELECT name FROM employees WHERE id=?',(old[1],)).fetchone()[0]}");dst.set(f"{old[2]} - {self.q('SELECT name FROM employees WHERE id=?',(old[2],)).fetchone()[0]}");qty.set(old[3]);doc.set(old[4] or '');reason.set(old[5] or '')
        ttk.Label(outer,text='البحث عن مادة',anchor='e').pack(fill='x');se=ttk.Entry(outer,textvariable=search,justify='right');se.pack(fill='x',ipady=5,pady=4);ic=ttk.Combobox(outer,textvariable=item,state='readonly',justify='right');ic.pack(fill='x',ipady=4)
        def load():
            pat='%'+search.get().strip()+'%';rows=self.q('SELECT id,name FROM items WHERE active=1 AND name LIKE ? ORDER BY name',(pat,)).fetchall();ic['values']=[f'{i} - {n}' for i,n in rows]
            if not item.get() and rows:item.set(ic['values'][0])
        se.bind('<KeyRelease>',lambda e:load());load();
        er=self.ids('employees');vals=[f'{i} - {n}' for i,n in er]
        for lab,var in [('من موظف',src),('إلى موظف',dst)]:ttk.Label(outer,text=lab,anchor='e').pack(fill='x',pady=(8,0));c=ttk.Combobox(outer,textvariable=var,values=vals,state='readonly',justify='right');c.pack(fill='x',ipady=4)
        rr=ttk.Frame(outer);rr.pack(fill='x',pady=8)
        for lab,var,w in [('🔢 العدد',qty,10),('المستند',doc,16),('سبب التحويل',reason,24)]:ttk.Label(rr,text=lab).pack(side='right',padx=4);ttk.Entry(rr,textvariable=var,width=w,justify='right').pack(side='right',padx=4)
        def save():
            try:i=self.parse(item.get());a=self.parse(src.get());b2=self.parse(dst.get());q=self.qty(qty.get())
            except Exception as x:return messagebox.showerror('خطأ',str(x),parent=win)
            if not all((i,a,b2)):return messagebox.showwarning('تنبيه','اختر المادة والموظفين',parent=win)
            if a==b2:return messagebox.showerror('خطأ','لا يمكن التحويل لنفس الموظف',parent=win)
            available=self.held(i,a)+(old[3] if old else 0)
            if available<q:return messagebox.showerror('خطأ','الكمية ليست بذمة الموظف الأول',parent=win)
            if tid:self.q('UPDATE transactions SET item_id=?,from_employee=?,to_employee=?,qty=?,doc_no=?,reason=? WHERE id=?',(i,a,b2,q,doc.get(),reason.get(),tid))
            else:self.q("INSERT INTO transactions(type,item_id,qty,from_employee,to_employee,date,doc_no,reason) VALUES('تحويل',?,?,?,?,?,?,?)",(i,q,a,b2,self.now(),doc.get(),reason.get()))
            self.commit();win.destroy();self.refresh()
        b=ttk.Frame(outer);b.pack(fill='x',pady=14);ttk.Button(b,text='💾 حفظ',command=save).pack(side='right',padx=4);ttk.Button(b,text='إلغاء',command=win.destroy).pack(side='right',padx=4)

    def return_tab(self):
        f=self.tabframe();self.page_header(f,'إرجاع مواد من الموظفين',lambda:self.print_tree(self.ret,'تقرير الإرجاع'))
        self.research=tk.StringVar();self.movement_search_row(f,'البحث عن مادة',self.research,lambda:self.load_movement_tree(self.ret,'return'))
        bar=ttk.Frame(f);bar.pack(fill='x',pady=4);ttk.Button(bar,text='↩ إرجاع مادة',command=lambda:self.return_dialog()).pack(side='right',padx=3);ttk.Button(bar,text='🗑 حذف',command=self.delete_return).pack(side='right',padx=3)
        self.ret=self.tree(f,['id','date','item','qty','employee','doc','reason'],['الرقم','التاريخ','المادة','الكمية','الموظف','المستند','السبب']);self.ret.pack(fill='both',expand=True);self.ret.bind('<<TreeviewSelect>>',lambda e:self.load_return_selection());self.load_movement_tree(self.ret,'return')

    def return_dialog(self, tid=None):
        win=tk.Toplevel(self.root);win.title('إرجاع مادة من الموظف');win.geometry('720x470');win.transient(self.root);win.grab_set();outer=self.scroll_body(win,18);ttk.Label(outer,text='إرجاع مادة من الموظف إلى المخزن',font=(self.font_family,16,'bold'),anchor='e').pack(fill='x',pady=(0,14))
        search=tk.StringVar();item=tk.StringVar();emp=tk.StringVar();qty=tk.StringVar(value='1');doc=tk.StringVar();reason=tk.StringVar();extract_to=tk.StringVar();old=None
        if tid:
            old=self.q('SELECT item_id,from_employee,qty,doc_no,reason FROM transactions WHERE id=?',(tid,)).fetchone();
            if old:item.set(f"{old[0]} - {self.q('SELECT name FROM items WHERE id=?',(old[0],)).fetchone()[0]}");emp.set(f"{old[1]} - {self.q('SELECT name FROM employees WHERE id=?',(old[1],)).fetchone()[0]}");qty.set(old[2]);doc.set(old[3] or '');reason.set(old[4] or '')
        ttk.Label(outer,text='البحث عن مادة',anchor='e').pack(fill='x');se=ttk.Entry(outer,textvariable=search,justify='right');se.pack(fill='x',ipady=5,pady=4);ic=ttk.Combobox(outer,textvariable=item,state='readonly',justify='right');ic.pack(fill='x',ipady=4)
        def load():
            pat='%'+search.get().strip()+'%';rows=self.q('SELECT id,name FROM items WHERE active=1 AND name LIKE ? ORDER BY name',(pat,)).fetchall();ic['values']=[f'{i} - {n}' for i,n in rows]
            if not item.get() and rows:item.set(ic['values'][0])
        se.bind('<KeyRelease>',lambda e:load());load();vals=[f'{i} - {n}' for i,n in self.ids('employees')];ttk.Label(outer,text='الموظف',anchor='e').pack(fill='x',pady=(8,0));ec=ttk.Combobox(outer,textvariable=emp,values=vals,state='readonly',justify='right');ec.pack(fill='x',ipady=4)
        rr=ttk.Frame(outer);rr.pack(fill='x',pady=8)
        for lab,var,w in [('🔢 العدد',qty,10),('المستند',doc,16),('سبب الإرجاع',reason,24)]:ttk.Label(rr,text=lab).pack(side='right',padx=4);ttk.Entry(rr,textvariable=var,width=w,justify='right').pack(side='right',padx=4)
        def save():
            try:i=self.parse(item.get());e=self.parse(emp.get());q=self.qty(qty.get())
            except Exception as x:return messagebox.showerror('خطأ',str(x),parent=win)
            if not i or not e:return messagebox.showwarning('تنبيه','اختر المادة والموظف',parent=win)
            if self.held(i,e)+(old[2] if old else 0)<q:return messagebox.showerror('خطأ','الكمية ليست بذمة الموظف',parent=win)
            if tid:self.q('UPDATE transactions SET item_id=?,from_employee=?,qty=?,doc_no=?,reason=? WHERE id=?',(i,e,q,doc.get(),reason.get(),tid))
            else:self.q("INSERT INTO transactions(type,item_id,qty,from_employee,date,doc_no,reason) VALUES('إرجاع',?,?,?,?,?,?)",(i,q,e,self.now(),doc.get(),reason.get()))
            self.commit();win.destroy();self.refresh()
        b=ttk.Frame(outer);b.pack(fill='x',pady=14);ttk.Button(b,text='💾 حفظ',command=save).pack(side='right',padx=4);ttk.Button(b,text='إلغاء',command=win.destroy).pack(side='right',padx=4)

    def out_tab(self):
        f=self.tabframe();self.page_header(f,'إخراج واستهلاك من المخزن',lambda:self.print_tree(self.ot,'تقرير الإخراج والاستهلاك'))
        self.osearch=tk.StringVar();self.movement_search_row(f,'البحث عن مادة',self.osearch,lambda:self.load_movement_tree(self.ot,'out'))
        bar=ttk.Frame(f);bar.pack(fill='x',pady=4);ttk.Button(bar,text='📤 إخراج/استهلاك مادة',command=lambda:self.out_dialog()).pack(side='right',padx=3);ttk.Button(bar,text='✏ تعديل',command=self.edit_stockout).pack(side='right',padx=3);ttk.Button(bar,text='🗑 حذف',command=self.delete_stockout).pack(side='right',padx=3)
        self.ot=self.tree(f,['id','date','item','qty','doc','reason','extract_to'],['الرقم','التاريخ','المادة','الكمية','المستند','السبب','استخراج إلى']);self.ot.pack(fill='both',expand=True);self.ot.bind('<<TreeviewSelect>>',lambda e:self.load_out_selection());self.load_movement_tree(self.ot,'out')

    def out_dialog(self, oid=None):
        win=tk.Toplevel(self.root);win.title('إخراج واستهلاك مادة');win.geometry('720x520');win.transient(self.root);win.grab_set();outer=self.scroll_body(win,18);ttk.Label(outer,text='إخراج / استهلاك مادة من المخزن',font=(self.font_family,16,'bold'),anchor='e').pack(fill='x',pady=(0,14))
        search=tk.StringVar();item=tk.StringVar();qty=tk.StringVar(value='1');doc=tk.StringVar();reason=tk.StringVar();extract_to=tk.StringVar();old=None
        if oid:
            old=self.q('SELECT item_id,qty,doc_no,reason,extract_to FROM stock_out WHERE id=?',(oid,)).fetchone();
            if old:item.set(f"{old[0]} - {self.q('SELECT name FROM items WHERE id=?',(old[0],)).fetchone()[0]}");qty.set(old[1]);doc.set(old[2] or '');reason.set(old[3] or '');extract_to.set(old[4] or '')
        ttk.Label(outer,text='البحث عن مادة',anchor='e').pack(fill='x');se=ttk.Entry(outer,textvariable=search,justify='right');se.pack(fill='x',ipady=5,pady=4);ic=ttk.Combobox(outer,textvariable=item,state='readonly',justify='right');ic.pack(fill='x',ipady=4)
        def load():
            pat='%'+search.get().strip()+'%';rows=self.q('SELECT id,name FROM items WHERE active=1 AND name LIKE ? ORDER BY name',(pat,)).fetchall();ic['values']=[f'{i} - {n}' for i,n in rows]
            if not item.get() and rows:item.set(ic['values'][0])
        se.bind('<KeyRelease>',lambda e:load());load();rr=ttk.Frame(outer);rr.pack(fill='x',pady=9)
        rr.grid_columnconfigure(0,weight=1,uniform='o'); rr.grid_columnconfigure(1,weight=1,uniform='o')
        for idx,(lab,var) in enumerate([('🔢 العدد',qty),('المستند',doc),('سبب الإخراج/الاستهلاك',reason),('استخراج إلى',extract_to)]):
            cell=ttk.Frame(rr); cell.grid(row=idx//2,column=1-(idx%2),sticky='ew',padx=6,pady=5)
            ttk.Label(cell,text=lab,anchor='e').pack(fill='x'); ttk.Entry(cell,textvariable=var,justify='right').pack(fill='x',ipady=5,pady=(3,0))
        def save():
            try:i=self.parse(item.get());q=self.qty(qty.get())
            except Exception as x:return messagebox.showerror('خطأ',str(x),parent=win)
            if not i:return messagebox.showwarning('تنبيه','اختر المادة',parent=win)
            if self.stock(i)+(old[1] if old else 0)<q:return messagebox.showerror('خطأ','الكمية غير متوفرة في المخزن',parent=win)
            if oid:self.q('UPDATE stock_out SET item_id=?,qty=?,doc_no=?,reason=?,extract_to=? WHERE id=?',(i,q,doc.get(),reason.get(),extract_to.get(),oid))
            else:self.q('INSERT INTO stock_out(item_id,qty,date,doc_no,reason,extract_to) VALUES(?,?,?,?,?,?)',(i,q,self.now(),doc.get(),reason.get(),extract_to.get()))
            self.commit();win.destroy();self.refresh()
        b=ttk.Frame(outer);b.pack(fill='x',pady=14);ttk.Button(b,text='💾 حفظ',command=save).pack(side='right',padx=4);ttk.Button(b,text='إلغاء',command=win.destroy).pack(side='right',padx=4)

    def load_movement_tree(self,tree,kind):
        if not tree:return
        self.clear(tree); qtxt='%' ; var=getattr(self, {'receipt':'rcsearch','dist':'disearch','transfer':'trsearch','return':'research','out':'osearch'}.get(kind,''),None)
        if var:qtxt='%'+var.get().strip()+'%'
        if kind=='receipt': rows=self.q("SELECT r.id,r.date,i.name,r.qty,r.doc_no,r.source,r.note FROM stock_receipts r JOIN items i ON i.id=r.item_id WHERE i.name LIKE ? ORDER BY r.id DESC LIMIT 500",(qtxt,))
        elif kind=='dist': rows=self.q("SELECT t.id,t.date,i.name,t.qty,e.name,t.doc_no,t.note FROM transactions t JOIN items i ON i.id=t.item_id JOIN employees e ON e.id=t.to_employee WHERE t.type='توزيع' AND i.name LIKE ? ORDER BY t.id DESC LIMIT 500",(qtxt,))
        elif kind=='transfer': rows=self.q("SELECT t.id,t.date,i.name,t.qty,e1.name,e2.name,t.doc_no,t.reason FROM transactions t JOIN items i ON i.id=t.item_id JOIN employees e1 ON e1.id=t.from_employee JOIN employees e2 ON e2.id=t.to_employee WHERE t.type='تحويل' AND i.name LIKE ? ORDER BY t.id DESC LIMIT 500",(qtxt,))
        elif kind=='return': rows=self.q("SELECT t.id,t.date,i.name,t.qty,e.name,t.doc_no,t.reason FROM transactions t JOIN items i ON i.id=t.item_id JOIN employees e ON e.id=t.from_employee WHERE t.type='إرجاع' AND i.name LIKE ? ORDER BY t.id DESC LIMIT 500",(qtxt,))
        else: rows=self.q("SELECT o.id,o.date,i.name,o.qty,o.doc_no,o.reason,o.extract_to FROM stock_out o JOIN items i ON i.id=o.item_id WHERE i.name LIKE ? ORDER BY o.id DESC LIMIT 500",(qtxt,))
        for r in rows:tree.insert('','end',values=r)

    def employee_liability_tab(self):
        f=self.tabframe(); self.page_header(f,'ذمم الموظفين',lambda:self.print_tree(self.held_tree,'تقرير ذمم الموظفين'))
        top=ttk.Frame(f); top.pack(fill='x',pady=(0,8))
        self.held_search=tk.StringVar(); self.held_employee=tk.StringVar()
        ttk.Label(top,text='بحث عن موظف',anchor='e').pack(side='right',padx=(8,4))
        se=ttk.Entry(top,textvariable=self.held_search,justify='right',font=(self.font_family,max(self.font_size+1,11)))
        se.pack(side='right',fill='x',expand=True,padx=4,ipady=4)
        ttk.Button(top,text='🔎 بحث',command=self.load_employee_liability).pack(side='right',padx=3)
        ttk.Button(top,text='🔄 تحديث',command=self.load_employee_liability).pack(side='right',padx=3)
        ttk.Label(top,text='الموظف',anchor='e').pack(side='right',padx=(14,4))
        self.held_combo=ttk.Combobox(top,textvariable=self.held_employee,state='readonly',justify='right',width=34)
        self.held_combo.pack(side='right',padx=4,ipady=4)
        self.held_combo.bind('<<ComboboxSelected>>',lambda e:self.load_employee_liability())
        se.bind('<KeyRelease>',lambda e:self.filter_held_employees())

        cards=ttk.Frame(f); cards.pack(fill='x',pady=6)
        self.held_count_var=tk.StringVar(value='0')
        self.held_qty_var=tk.StringVar(value='0')
        self.held_name_var=tk.StringVar(value='')
        for label,var in [('الموظف',self.held_name_var),('عدد الأصناف',self.held_count_var),('إجمالي الكميات',self.held_qty_var)]:
            box=ttk.LabelFrame(cards,text=label,padding=10); box.pack(side='right',fill='both',expand=True,padx=5)
            ttk.Label(box,textvariable=var,font=(self.font_family,16,'bold'),anchor='center').pack(fill='both',expand=True)

        self.held_tree=self.tree(f,['id','item','category','unit','qty','last_date','note'],['الرقم','المادة','التصنيف','الوحدة','العدد','آخر حركة','ملاحظات'])
        self.held_tree.pack(fill='both',expand=True)
        self.held_employee_ids=[]
        self.filter_held_employees()
        self.load_employee_liability()

    def filter_held_employees(self):
        if not hasattr(self,'held_combo'): return
        term=self.held_search.get().strip()
        rows=self.q('SELECT id,name FROM employees WHERE active=1 AND name LIKE ? ORDER BY name',('%'+term+'%',)).fetchall()
        self.held_employee_ids=rows
        vals=[f'{i} - {n}' for i,n in rows]
        self.held_combo['values']=vals
        if self.held_employee.get() not in vals:
            self.held_employee.set(vals[0] if vals else '')
        self.load_employee_liability()

    def load_employee_liability(self):
        if not hasattr(self,'held_tree'): return
        self.clear(self.held_tree)
        selected=self.held_employee.get().strip()
        emp_id=None
        if selected:
            try: emp_id=int(selected.split(' - ',1)[0])
            except Exception: emp_id=None
        if not emp_id:
            self.held_name_var.set('')
            self.held_count_var.set('0'); self.held_qty_var.set('0')
            return
        emp=self.q('SELECT name FROM employees WHERE id=?',(emp_id,)).fetchone()
        self.held_name_var.set(emp[0] if emp else '')
        rows=self.q("""
            SELECT i.id,i.name,i.category,i.unit,
                   COALESCE(SUM(CASE WHEN t.to_employee=? THEN t.qty ELSE 0 END),0)
                   -COALESCE(SUM(CASE WHEN t.from_employee=? THEN t.qty ELSE 0 END),0) AS balance,
                   COALESCE(MAX(t.date),'') AS last_date,
                   COALESCE(i.note,'')
            FROM items i
            JOIN transactions t ON t.item_id=i.id
            WHERE (t.to_employee=? OR t.from_employee=?) AND i.active=1
            GROUP BY i.id,i.name,i.category,i.unit,i.note
            HAVING balance>0
            ORDER BY i.name
        """,(emp_id,emp_id,emp_id,emp_id)).fetchall()
        for r in rows:
            self.held_tree.insert('','end',values=r)
        self.held_count_var.set(str(len(rows)))
        self.held_qty_var.set(str(sum(int(r[4] or 0) for r in rows)))

    def ledger_tab(self):
        f=self.tabframe(); self.page_header(f,'سجل الحركات والذمم',lambda:self.print_tree(self.lt,'سجل الحركات والذمم'))
        top=ttk.Frame(f); top.pack(fill='x'); self.search=tk.StringVar(); ttk.Label(top,text='بحث بالاسم أو المادة').pack(side='right'); ttk.Entry(top,textvariable=self.search,width=38,justify='right').pack(side='right',padx=6); ttk.Button(top,text='🔎 بحث',command=self.load_ledger).pack(side='right'); ttk.Button(top,text='عرض الكل',command=lambda:(self.search.set(''),self.load_ledger())).pack(side='right',padx=4)
        self.lt=self.tree(f,['id','date','type','item','qty','from','to','doc','reason'],['الرقم','التاريخ','الحركة','المادة','الكمية','من','إلى','المستند','السبب']); self.lt.pack(fill='both',expand=True)
    def _version_tuple(self,v):
        import re
        nums=re.findall(r'\d+',str(v))
        return tuple(int(x) for x in nums) if nums else (0,)

    def updates_tab(self):
        f=self.tabframe(); self.page_header(f,'التحديثات')
        box=ttk.LabelFrame(f,text='نظام التحديثات',padding=18); box.pack(fill='x',pady=8)
        info=getattr(self,'update_info',None)
        if not hasattr(self,'update_status_var'): self.update_status_var=TrVar(value='لم يتم الفحص بعد.')
        ttk.Label(box,text=f'الإصدار الحالي: {APP_VERSION}',font=(self.font_family,13,'bold'),anchor='e').pack(fill='x',pady=5)
        ttk.Label(box,textvariable=self.update_status_var,anchor='e',justify='right').pack(fill='x',pady=8)
        if info:
            notes=str(info.get('notes') or '').strip()
            if notes: ttk.Label(box,text='ما الجديد: '+notes,anchor='e',justify='right',wraplength=800).pack(fill='x',pady=(0,8))
        row=ttk.Frame(box); row.pack(fill='x',pady=5)
        if info:
            ttk.Button(row,text=f"⬇  تحديث الآن إلى {info.get('version','')}",command=self.install_update).pack(side='right',padx=(0,8))
        ttk.Button(row,text='🔎 فحص التحديثات الآن',command=self.check_for_updates).pack(side='right')
        ttk.Label(box,text='عند توفر إصدار أحدث يظهر تنبيه أحمر بجانب زر التحديثات. اضغط «تحديث الآن» ليُحمَّل التحديث ويُثبَّت ويعاد تشغيل البرنامج؛ قاعدة البيانات والإعدادات لا تتغير ويؤخذ منها نسخة احتياطية قبل التحديث.',anchor='e',justify='right',wraplength=800).pack(fill='x',pady=(12,0))

    def _version_tuple(self,v):
        nums=re.findall(r'\d+',str(v))
        return tuple(int(x) for x in nums) if nums else (0,)

    def _update_url(self):
        url=''
        try:
            if self.current=='الإعدادات' and hasattr(self,'update_server_var'): url=self.update_server_var.get().strip()
        except Exception: pass
        url=url or self.get_setting('update_server') or UPDATE_SOURCE_URL
        if url in OLD_UPDATE_URLS: url=UPDATE_SOURCE_URL
        return url

    def _set_update_notice(self,latest=None,error=None,data=None,silent=False):
        if error:
            if not silent and hasattr(self,'update_status_var'): self.update_status_var.set('تعذر فحص التحديثات. تأكد من اتصال الإنترنت.')
            return
        if data is not None: latest=data.get('version') or data.get('latest_version') or data.get('tag_name')
        latest=str(latest or '')
        newer=bool(latest) and self._version_tuple(latest)>self._version_tuple(APP_VERSION)
        self.update_info=dict(data or {'version':latest}) if newer else None
        if newer:
            if self.get_setting('update_notify')=='1': self.updates_bottom.set_alert(True,f'التحديثات  •  إصدار {latest}')
            msg=f'يتوفر تحديث جديد: الإصدار {latest}'
        else:
            self.updates_bottom.set_alert(False,'التحديثات')
            msg='لا توجد تحديثات جديدة. أنت تستخدم أحدث إصدار.'
        if hasattr(self,'update_status_var'): self.update_status_var.set(msg)
        if getattr(self,'current','')=='التحديثات' and not silent:
            try: self.show_page('التحديثات',self.updates_tab)
            except Exception: pass

    def check_for_updates(self,silent=False):
        # الشبكة في خيط خلفي لا يلمس واجهة Tk؛ النتيجة تُقرأ من الخيط الرئيسي
        if getattr(self,'_update_check_running',False): return
        self._update_check_running=True
        url=self._update_url(); box={}
        def worker():
            try:
                sep='&' if '?' in url else '?'
                req=urllib.request.Request(url+sep+'cb='+str(int(time.time())),headers={'User-Agent':'FixedAssetsManagement/'+APP_VERSION,'Cache-Control':'no-cache'})
                with urllib.request.urlopen(req,timeout=10) as r: box['data']=json.loads(r.read().decode('utf-8-sig'))
            except Exception as e: box['error']=e
            box['done']=True
        def poll():
            if not box.get('done'):
                try: self.root.after(200,poll)
                except Exception: pass
                return
            self._update_check_running=False
            try:
                if 'error' in box: self._set_update_notice(error=box['error'],silent=silent)
                else: self._set_update_notice(data=box['data'],silent=silent)
            except Exception: pass
        threading.Thread(target=worker,daemon=True).start()
        self.root.after(200,poll)

    def _start_update_loop(self):
        # رسالة فشل التحديث السابق إن وُجدت
        try:
            err=BASE_DIR/'update_error.txt'
            if err.exists():
                err.unlink(); messagebox.showwarning('التحديث','فشل تثبيت التحديث السابق. بقي البرنامج على الإصدار الحالي.')
        except Exception: pass
        def tick():
            try:
                if self.get_setting('update_auto_check')=='1': self.check_for_updates(silent=True)
            except Exception: pass
            try: self.root.after(10*60*1000,tick)
            except Exception: pass
        self.root.after(2500,tick)

    def install_update(self):
        info=getattr(self,'update_info',None)
        if not info: return messagebox.showinfo('التحديث','لا يوجد تحديث متاح حالياً.')
        ver=info.get('version','')
        raw=str(info.get('download_url') or info.get('download') or '').strip()
        if not raw: return messagebox.showerror('التحديث','رابط تحميل التحديث غير موجود في ملف الإصدار.')
        if not messagebox.askyesno('تحديث البرنامج',f'سيتم تحديث البرنامج إلى الإصدار {ver} ثم إعادة تشغيله.\nقاعدة البيانات والإعدادات لن تتغير، ويؤخذ منها نسخة احتياطية.\n\nمتابعة؟'): return
        if not raw.startswith(('http://','https://')): raw=self._update_url().split('?')[0].rsplit('/',1)[0]+'/'+raw.lstrip('/')
        sha=str(info.get('sha256') or '').strip().lower()
        if hasattr(self,'update_status_var'): self.update_status_var.set('جاري تحميل التحديث...')
        self.root.configure(cursor='watch')
        box={}
        def worker():
            try:
                work=BASE_DIR/'_update_work'; work.mkdir(exist_ok=True)
                stage=work/('package_'+str(int(time.time()))); stage.mkdir(parents=True)
                zpath=stage/'update.zip'
                req=urllib.request.Request(raw+('&' if '?' in raw else '?')+'cb='+str(int(time.time())),headers={'User-Agent':'FixedAssetsManagement/'+APP_VERSION,'Cache-Control':'no-cache'})
                with urllib.request.urlopen(req,timeout=60) as r, open(zpath,'wb') as out: shutil.copyfileobj(r,out)
                if sha:
                    h=hashlib.sha256(open(zpath,'rb').read()).hexdigest().lower()
                    if h!=sha: raise RuntimeError('فشل التحقق من سلامة ملف التحديث (SHA-256).')
                ext=stage/'extract'; ext.mkdir(); root_=ext.resolve()
                with zipfile.ZipFile(zpath) as z:
                    for m in z.infolist():
                        t=(ext/m.filename).resolve()
                        if t!=root_ and root_ not in t.parents: raise RuntimeError('ملف التحديث يحتوي على مسار غير آمن.')
                    z.extractall(ext)
                src=ext
                for p,_d,files in os.walk(ext):
                    if PROGRAM_FILE in files: src=Path(p); break
                else: raise RuntimeError('ملف التحديث لا يحتوي على '+PROGRAM_FILE)
                payload=stage/'payload'; payload.mkdir()
                for p in src.iterdir():
                    if p.suffix.lower() in ('.sqlite','.db','.bak') or p.name in ('_update_work','Backups','__MACOSX'): continue
                    if p.is_dir(): shutil.copytree(p,payload/p.name,dirs_exist_ok=True)
                    else: shutil.copy2(p,payload/p.name)
                box['payload']=payload; box['work']=work
            except Exception as e: box['error']=e
            box['done']=True
        def poll():
            if not box.get('done'):
                self.root.after(200,poll); return
            self.root.configure(cursor='')
            if 'error' in box:
                try: shutil.rmtree(BASE_DIR/'_update_work',ignore_errors=True)
                except Exception: pass
                if hasattr(self,'update_status_var'): self.update_status_var.set('فشل التحديث.')
                return messagebox.showerror('التحديث','تعذر تنزيل أو تجهيز التحديث:\n'+str(box['error']))
            self._apply_update(box['payload'],box['work'],ver)
        threading.Thread(target=worker,daemon=True).start()
        self.root.after(200,poll)

    def _apply_update(self,payload,work,ver):
        try:
            if DB.exists():
                shutil.copy2(DB,BASE_DIR/'fixed_assets_before_update.sqlite.bak')
        except Exception: pass
        if os.name=='nt':
            bat=BASE_DIR/'_apply_update.bat'
            lines=['@echo off','setlocal',f'set "STAGING={payload}"',f'set "TARGET={BASE_DIR}"',f'set "WORK={work}"',f'set "PID={os.getpid()}"',
                   ':waitloop','tasklist /FI "PID eq %PID%" 2>NUL | find /I "%PID%" >NUL',
                   'if not errorlevel 1 (timeout /t 1 /nobreak >NUL & goto waitloop)','timeout /t 1 /nobreak >NUL',
                   'robocopy "%STAGING%" "%TARGET%" /E /XF "fixed_assets.sqlite" "*.sqlite" "*.bak" "_apply_update.bat" /XD "Backups" /R:3 /W:1 >NUL',
                   'if errorlevel 8 (echo UPDATE_FAILED> "%TARGET%\\update_error.txt" & exit /b 1)',
                   'rmdir /S /Q "%WORK%" >NUL 2>NUL',
                   'if exist "%TARGET%\\Run_FixedAssetsManagement.bat" (start "" "%TARGET%\\Run_FixedAssetsManagement.bat") else (cd /d "%TARGET%" & start "" py -3 FixedAssetsManagement.py)',
                   'del /F /Q "%TARGET%\\_apply_update.bat" >NUL 2>NUL','endlocal']
            bat.write_text('\r\n'.join(lines)+'\r\n',encoding='utf-8')
            subprocess.Popen(['cmd.exe','/c','start','','/min',str(bat)],cwd=str(BASE_DIR),creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),close_fds=True)
            messagebox.showinfo('التحديث',f'سيُغلق البرنامج الآن ويُثبَّت الإصدار {ver} ثم يُعاد تشغيله تلقائياً.')
            self.root.destroy()
        else:
            for p in payload.iterdir():
                d=BASE_DIR/p.name
                if p.is_dir(): shutil.copytree(p,d,dirs_exist_ok=True)
                else: shutil.copy2(p,d)
            shutil.rmtree(work,ignore_errors=True)
            messagebox.showinfo('التحديث',f'تم تثبيت الإصدار {ver}. أعد تشغيل البرنامج.')

    def set_setting(self,k,v):
        self.conn.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',(k,str(v))); self.conn.commit()
    def _v(self,key,factory):
        # متغيرات الصفحة تبقى حيّة أثناء إعادة بناء الصفحة (معاينة المظهر) وتُمسح عند مغادرتها
        d=self.__dict__.setdefault('_svars',{})
        if key not in d: d[key]=factory()
        return d[key]
    def _ui_entry(self,parent,var,show=''):
        P=self.current_palette()
        return tk.Entry(parent,textvariable=var,show=show,justify='right',relief='flat',bd=0,font=(self.font_family,max(10,self.font_size)),bg=P['inp'],fg=P['fg'],insertbackground=P['fg'],highlightthickness=1,highlightbackground=P['border'],highlightcolor=self.capsule_color)
    def _ui_btn(self,parent,text,cmd,kind='soft'):
        P=self.current_palette()
        bgc,fgc={'primary':(self.primary_color,'#ffffff'),'soft':(P['soft_bg'],P['soft_fg']),'danger':(P['dng_bg'],P['dng_fg'])}[kind]
        return tk.Button(parent,text=text,command=cmd,bg=bgc,fg=fgc,activebackground=bgc,activeforeground=fgc,relief='flat',bd=0,highlightthickness=0,cursor='hand2',font=(self.font_family,max(10,self.font_size),'bold'),padx=12,pady=6)

    def settings_tab(self):
        P=self.current_palette(); bg=P['bg']; card=P['card']; head=P['head']; border=P['border']; tcol=P['title']; sub=P['sub']; txt=P['fg']
        cap=self.capsule_color; off=P['off']; inp=P['inp']
        ff=self.font_family; fs=max(10,self.font_size); fw='bold' if self.font_bold else 'normal'
        try:
            ttk.Style(self.root).configure('Soft.Vertical.TScrollbar',troughcolor=bg,background=border,bordercolor=bg,lightcolor=border,darkcolor=border,arrowcolor=sub,relief='flat')
        except Exception: pass

        # ---- متغيرات الصفحة ----
        V=self._v
        self.theme_var=V('theme',lambda:tk.StringVar(value=self.theme_name))
        self.font_var=V('font',lambda:tk.StringVar(value=self.font_family))
        self.size_var=V('size',lambda:tk.StringVar(value=str(self.font_size)))
        self.style_var=V('style',lambda:tk.StringVar(value='عريض' if self.font_bold else 'عادي'))
        self.color_var=V('color',lambda:tk.StringVar(value=self.font_color))
        self.primary_var=V('primary',lambda:tk.StringVar(value=self.primary_color))
        self.capsule_var=V('capsule',lambda:tk.StringVar(value=self.capsule_color))
        self.heading_var=V('heading',lambda:tk.StringVar(value=self.heading_color))
        self.bg_var=V('bgc',lambda:tk.StringVar(value=self.background_color))
        self.language_var=V('language',lambda:tk.StringVar(value=self.language))
        self.date_var=V('date',lambda:tk.StringVar(value=self.date_format))
        self.row_numbers_var=V('rn',lambda:tk.BooleanVar(value=self.get_setting('show_row_numbers')=='1'))
        self.grid_lines_var=V('gl',lambda:tk.BooleanVar(value=self.get_setting('grid_lines')=='1'))
        self.row_select_var=V('rs',lambda:tk.BooleanVar(value=self.get_setting('row_select_color')=='1'))
        self.row_height_var=V('rh',lambda:tk.StringVar(value=self.get_setting('row_height') or 'متوسط'))
        self.update_notify_var=V('un',lambda:tk.BooleanVar(value=self.get_setting('update_notify')=='1'))
        self.sounds_var=V('snd',lambda:tk.BooleanVar(value=self.get_setting('sounds')=='1'))
        self.autosave_var=V('as',lambda:tk.BooleanVar(value=self.get_setting('autosave_settings')=='1'))
        self.confirm_delete_var=V('cd',lambda:tk.BooleanVar(value=self.get_setting('confirm_delete')=='1'))
        self.backup_path_var=V('bp',lambda:tk.StringVar(value=self.get_setting('backup_path') or str(BASE_DIR/'Backups')))
        self.backup_frequency_var=V('bf',lambda:tk.StringVar(value=self.get_setting('backup_frequency') or 'أسبوعي'))
        self.update_auto_var=V('ua',lambda:tk.BooleanVar(value=self.get_setting('update_auto_check')=='1'))
        self.update_server_var=V('us',lambda:tk.StringVar(value=self.get_setting('update_server') or UPDATE_SOURCE_URL))
        self.hijri_var=V('hj',lambda:tk.BooleanVar(value=self.get_setting('language_hijri')=='1'))
        self.old_pw=V('opw',lambda:tk.StringVar()); self.new_pw=V('npw',lambda:tk.StringVar()); self.confirm_pw=V('cpw',lambda:tk.StringVar())

        # ---- هيكل الصفحة ----
        outer=tk.Frame(self.content,bg=bg); outer._custom=True; outer.pack(fill='both',expand=True)
        top=tk.Frame(outer,bg=bg,padx=26,pady=14); top.pack(fill='x')
        self._ui_btn(top,'💾  حفظ الإعدادات',self.save_settings,'primary').pack(side='left')
        tr=tk.Frame(top,bg=bg); tr.pack(side='right',fill='x',expand=True)
        line=tk.Frame(tr,bg=bg); line.pack(fill='x')
        tk.Label(line,text='⚙',font=(ff,max(24,fs+14)),bg=bg,fg=self.primary_color).pack(side='right',padx=(10,0))
        tk.Label(line,text='الإعدادات',font=(ff,max(22,fs+12),'bold'),bg=bg,fg=tcol).pack(side='right')
        tk.Label(tr,text='تخصيص مظهر البرنامج وإعداداته العامة',font=(ff,fs),bg=bg,fg=sub,anchor='e',justify='right').pack(fill='x',pady=(2,0))

        holder=tk.Frame(outer,bg=bg); holder.pack(fill='both',expand=True,padx=(14,6),pady=(0,10))
        canvas=tk.Canvas(holder,bg=bg,highlightthickness=0,bd=0,yscrollincrement=20)
        scroll=ttk.Scrollbar(holder,orient='vertical',command=canvas.yview,style='Soft.Vertical.TScrollbar')
        canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y'); canvas.pack(side='left',fill='both',expand=True)
        inner=tk.Frame(canvas,bg=bg); win=canvas.create_window((0,0),window=inner,anchor='nw')
        inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(win,width=e.width))
        canvas._page_scroller=True; self._wheel_target=canvas; self._settings_canvas=canvas
        inner.grid_columnconfigure(0,weight=1,uniform='col',minsize=400); inner.grid_columnconfigure(1,weight=1,uniform='col',minsize=400)

        # ---- أدوات مساعدة للبطاقات ----
        def card_(title,icon,row,col,span=1):
            rb=RoundBox(inner,fill=card,outline=border,outer=bg,radius=16,pad=14)
            rb.grid(row=row,column=col,columnspan=span,sticky='nsew',padx=8,pady=8)
            body=rb.body
            hd=tk.Frame(body,bg=head); hd.pack(fill='x',pady=(0,12))
            tk.Label(hd,text=icon,font=(ff,fs+4),bg=head,fg=tcol).pack(side='right',padx=(6,12),pady=10)
            tk.Label(hd,text=title,font=(ff,fs+3,'bold'),bg=head,fg=tcol,anchor='e').pack(side='right')
            return body
        def lab(parent,text,**kw):
            return tk.Label(parent,text=text,font=(ff,fs,fw),bg=card,fg=txt,anchor='e',justify='right',**kw)
        def toggle_row(parent,text,var,cmd=None):
            r=tk.Frame(parent,bg=card); r.pack(fill='x',pady=6)
            Toggle(r,var,cap,off,card,cmd).pack(side='right')
            lab(r,text).pack(side='right',padx=(0,12))
        def field_row(parent,text,make):
            r=tk.Frame(parent,bg=card); r.pack(fill='x',pady=6)
            lab(r,text,width=10).pack(side='right',padx=(12,0))
            w=make(r); w.pack(side='left',fill='x',expand=True)
        def dd(parent,var,values,cmd=None):
            return Dropdown(parent,var,values,(ff,fs,fw),txt,inp,border,card,txt,cmd)

        # ---- المظهر العام ----
        body=card_('المظهر العام','🎨',0,0)
        row=tk.Frame(body,bg=card); row.pack(fill='x',pady=(0,4))
        modes=[('داكن','☾','داكن','#2b3138','#2b3138','#ffffff'),('داكن مائل','☾','داكن مائل','#223a57','#223a57','#ffffff'),('فاتح مائل','☀','متوسط','#e0efff','#8cbcf5','#2563eb'),('فاتح','☀','فاتح','#eef2f6','#cbd5e1','#475569')]
        for label,icon,key,fill_,out_,fgc in modes:
            ThemeTile(row,label,icon,fill_,out_,fgc,self.theme_var.get()==key,cap,card,lambda k=key:self.preview_theme(k),(ff,fs,'bold')).pack(side='right',fill='x',expand=True,padx=4)

        # ---- الخط ----
        body=card_('حجم الخط ونوعه','Aa',0,1)
        try: installed=set(tkfont.families(self.root))
        except Exception: installed=set()
        fonts=[f for f in ('Cairo','Tahoma','Segoe UI','Arial','Calibri','Times New Roman','Traditional Arabic','Sakkal Majalla') if f in installed] or ['Tahoma','Arial','Segoe UI','Times New Roman']
        if self.font_var.get() not in fonts: fonts.insert(0,self.font_var.get())
        r=tk.Frame(body,bg=card); r.pack(fill='x',pady=6)
        lab(r,'حجم الخط',width=10).pack(side='right',padx=(12,0))
        tk.Label(r,textvariable=self.size_var,font=(ff,fs,fw),bg=inp,fg=txt,width=4,pady=6,highlightthickness=1,highlightbackground=border).pack(side='left')
        Slider(r,self.size_var,9,20,cap,off,card,self.preview_font).pack(side='left',fill='x',expand=True,padx=(0,12))
        field_row(body,'نوع الخط',lambda p:dd(p,self.font_var,fonts,self.preview_font))
        field_row(body,'شكل الخط',lambda p:dd(p,self.style_var,['عادي','عريض'],self.preview_font))

        # ---- ألوان الواجهة ----
        body=card_('ألوان الواجهة','💧',1,0)
        g=tk.Frame(body,bg=card); g.pack(fill='x')
        g.grid_columnconfigure(0,weight=1,uniform='cf'); g.grid_columnconfigure(2,weight=1,uniform='cf')
        for r_,pair,text,var in [(0,1,'اللون الأساسي',self.primary_var),(0,0,'لون الكبسولات',self.capsule_var),(1,1,'لون العناوين',self.heading_var),(1,0,'لون الخلفية',self.bg_var),(2,1,'لون الخط',self.color_var)]:
            ColorField(g,var,inp,border,lambda v=var:self.choose_color_for(v)).grid(row=r_,column=pair*2,sticky='ew',padx=(0,6),pady=6)
            lab(g,text).grid(row=r_,column=pair*2+1,sticky='e',padx=(0,12))

        # ---- الجداول ----
        body=card_('إعدادات الجداول','▦',1,1)
        for text,var in [('إظهار أرقام الصفوف',self.row_numbers_var),('خطوط تفصيلية للجداول',self.grid_lines_var),('تحديد الصف باللون',self.row_select_var)]:
            toggle_row(body,text,var,self._auto)
        field_row(body,'ارتفاع الصفوف',lambda p:dd(p,self.row_height_var,['صغير','متوسط','كبير'],self._auto))

        # ---- عامة ----
        body=card_('إعدادات عامة','⚙',2,0)
        toggle_row(body,'تشغيل تنبيه التحديثات',self.update_notify_var,self._auto)
        toggle_row(body,'تشغيل الأصوات',self.sounds_var,self._auto)
        toggle_row(body,'حفظ الإعدادات تلقائيًا',self.autosave_var,lambda:self.save_settings(silent=True))
        toggle_row(body,'تأكيد قبل الحذف',self.confirm_delete_var,self._auto)

        # ---- النسخ الاحتياطي ----
        body=card_('النسخ الاحتياطي','🗄',2,1)
        lab(body,'موقع حفظ النسخة').pack(fill='x',pady=(0,6))
        pr=tk.Frame(body,bg=card); pr.pack(fill='x',pady=(0,6))
        self._ui_btn(pr,'📁',self.pick_backup_dir,'soft').pack(side='left',padx=(0,8))
        self._ui_entry(pr,self.backup_path_var).pack(side='left',fill='x',expand=True,ipady=6)
        field_row(body,'التكرار التلقائي',lambda p:dd(p,self.backup_frequency_var,['يومي','أسبوعي','شهري'],self._auto))
        self._ui_btn(body,'🗄   إنشاء نسخة احتياطية الآن',self.create_backup,'soft').pack(fill='x',pady=(8,0),ipady=4)

        # ---- التحديثات ----
        body=card_('إعدادات التحديثات','☁',3,0)
        toggle_row(body,'فحص التحديثات تلقائيًا',self.update_auto_var,self._auto)
        sr=tk.Frame(body,bg=card); sr.pack(fill='x',pady=6)
        lab(sr,'الخادم',width=6).pack(side='right',padx=(10,0))
        self._ui_btn(sr,'↗',self.open_update_server,'soft').pack(side='left',padx=(8,0))
        self._ui_entry(sr,self.update_server_var).pack(side='left',fill='x',expand=True,ipady=6)
        self._ui_btn(body,'🔎   فحص التحديثات الآن',self.check_for_updates,'soft').pack(fill='x',pady=(8,0),ipady=4)

        # ---- اللغة ----
        body=card_('اللغة والوقت','🌐',3,1)
        field_row(body,'اللغة',lambda p:dd(p,self.language_var,list(I18N.available().values()),self._auto))
        field_row(body,'تنسيق التاريخ',lambda p:dd(p,self.date_var,['يوم/شهر/سنة','سنة-شهر-يوم'],self._auto))
        toggle_row(body,'استخدام التقويم الهجري أيضًا',self.hijri_var,self._auto)

        # ---- الأمان ----
        body=card_('الأمان وتغيير كلمة السر','🔐',4,0,2)
        rr=tk.Frame(body,bg=card); rr.pack(fill='x')
        for text,var in [('كلمة السر الحالية',self.old_pw),('كلمة السر الجديدة',self.new_pw),('تأكيد كلمة السر',self.confirm_pw)]:
            cell=tk.Frame(rr,bg=card); cell.pack(side='right',fill='x',expand=True,padx=6)
            lab(cell,text).pack(fill='x',pady=(0,4)); self._ui_entry(cell,var,show='●').pack(fill='x',ipady=7)
        self._ui_btn(body,'🔐  تغيير كلمة السر',self.change_password,'primary').pack(anchor='e',pady=(12,0),padx=6)

        # ---- إدارة القوائم ----
        for idx,(title,table,varname) in enumerate([('الشعب','divisions','division'),('الوحدات','units_list','unit'),('تصنيفات الأصناف','categories','category'),('وحدات القياس','item_units','itemunit')]):
            body=card_(title,'☷',5+idx//2,idx%2); self.list_manager(body,title,table,varname)

    def list_manager(self,parent,title,table,varname):
        P=self.current_palette(); var=tk.StringVar(); setattr(self,varname+'_setting_var',var)
        r=tk.Frame(parent,bg=P['card']); r.pack(fill='x')
        self._ui_btn(r,'🗑 حذف',lambda:self.delete_list_value(table,var),'danger').pack(side='left',padx=(0,4))
        self._ui_btn(r,'✏ تعديل',lambda:self.edit_list_value(table,var),'soft').pack(side='left',padx=(0,4))
        self._ui_btn(r,'➕ إضافة',lambda:self.add_list_value(table,var),'primary').pack(side='left',padx=(0,8))
        self._ui_entry(r,var).pack(side='left',fill='x',expand=True,ipady=6)
        lb=tk.Listbox(parent,height=4,font=(self.font_family,max(10,self.font_size)),bg=P['inp'],fg=P['fg'],relief='flat',bd=0,highlightthickness=1,highlightbackground=P['border'],highlightcolor=P['border'],selectbackground=self.capsule_color,selectforeground='#ffffff',activestyle='none')
        lb.pack(fill='x',pady=(8,0)); setattr(self,varname+'_setting_list',lb); self.populate_list(table,lb); lb.bind('<<ListboxSelect>>',lambda e:self.list_selected(lb,var))

    def choose_color_for(self,var):
        c=colorchooser.askcolor(color=var.get(),title='اختيار اللون',parent=self.root)
        if c and c[1]: var.set(c[1]); self.apply_preview_colors()
    def preview_theme(self,value):
        self.theme_var.set(value); self.theme_name=value; self.apply_theme(); self._rebuild_settings(); self._auto()
    def _ok_color(self,v,old):
        try: self.root.winfo_rgb(v); return v
        except Exception: return old
    def apply_preview_colors(self):
        self.primary_color=self._ok_color(self.primary_var.get(),self.primary_color)
        self.capsule_color=self._ok_color(self.capsule_var.get(),self.capsule_color)
        self.heading_color=self._ok_color(self.heading_var.get(),self.heading_color)
        self.background_color=self._ok_color(self.bg_var.get(),self.background_color)
        self.font_color=self._ok_color(self.color_var.get(),self.font_color)
        self.apply_theme(); self._rebuild_settings(); self._auto()
    def preview_font(self,*args):
        try:self.font_size=int(self.size_var.get())
        except Exception:self.font_size=10
        self.font_family=self.font_var.get() or self.font_family; self.font_bold=(self.style_var.get()=='عريض')
        self.apply_theme(); self._rebuild_settings(); self._auto()
    def _auto(self,*args):
        # حفظ تلقائي عند تفعيل «حفظ الإعدادات تلقائيًا»
        try:
            if self.autosave_var.get(): self.save_settings(silent=True)
        except Exception: pass
    def _rebuild_settings(self):
        if self.current!='الإعدادات': return
        try: y=self._settings_canvas.yview()[0]
        except Exception: y=0
        for w in self.content.winfo_children(): w.destroy()
        self.settings_tab(); self.apply_theme()
        self.root.after(60,lambda:self._restore_scroll(y))
    def _restore_scroll(self,y):
        try: self._settings_canvas.yview_moveto(y)
        except Exception: pass
    def _can_scroll(self,w,step):
        try:
            lo,hi=w.yview()
            return (lo>0.0005) if step<0 else (hi<0.9995)
        except Exception: return False
    def _on_wheel(self,e):
        # الأولوية: تحريك الصفحة الأقرب (حاوية scroll_body أو صفحة الإعدادات)، وإذا انتهت يتحرك الجدول/القائمة تحتها
        try:
            num=getattr(e,'num',0); delta=getattr(e,'delta',0) or 0
            if num==4: step=-1
            elif num==5: step=1
            elif delta: step=-1 if delta>0 else 1
            else: return None
            mag=max(1,abs(int(delta))//120) if delta else 1
            try: w=self.root.winfo_containing(e.x_root,e.y_root)
            except Exception: w=None
            if w is None: w=getattr(e,'widget',None)
            page=None; inner=None; cur=w
            while cur is not None:
                if inner is None and isinstance(cur,(ttk.Treeview,tk.Listbox,tk.Text)): inner=cur
                if getattr(cur,'_page_scroller',False): page=cur; break
                cur=getattr(cur,'master',None)
            if page is not None and w is not None:
                try:
                    if w.winfo_toplevel() is not page.winfo_toplevel(): page=None
                except Exception: page=None
            if page is not None and self._can_scroll(page,step):
                page.yview_scroll(step*mag*3,'units'); return 'break'
            if inner is not None and self._can_scroll(inner,step):
                inner.yview_scroll(step*mag*3,'units')
            return 'break'
        except Exception:
            return None
    def pick_backup_dir(self):
        d=filedialog.askdirectory(parent=self.root,initialdir=self.backup_path_var.get() or str(BASE_DIR))
        if d: self.backup_path_var.set(d); self._auto()
    def open_update_server(self):
        try: webbrowser.open(self.update_server_var.get().strip() or UPDATE_SOURCE_URL)
        except Exception: pass
    def load_preferences(self):
        self.theme_name=self.get_setting('theme') or 'فاتح'
        self.font_family=self._font_ok(self.get_setting('font_family') or 'Tahoma')
        try:self.font_size=max(8,min(24,int(self.get_setting('font_size') or 10)))
        except Exception:self.font_size=10
        self.font_bold=self.get_setting('font_bold')=='1'
        self.font_color=self._color('font_color','#111111')
        self.primary_color=self._color('primary_color','#2589ef')
        self.capsule_color=self._color('capsule_color','#1677ff')
        self.heading_color=self._color('heading_color','#17283b')
        self.background_color=self._color('background_color','#f4f7fb')
        self.language=self.get_setting('language') or 'العربية'
        self.date_format=self.get_setting('date_format') or 'يوم/شهر/سنة'

    def save_settings(self,silent=False):
        try:size=int(self.size_var.get())
        except Exception:size=10
        values=[
            ('theme',self.theme_var.get()),('font_family',self.font_var.get()),('font_size',str(size)),('font_bold','1' if self.style_var.get()=='عريض' else '0'),
            ('font_color',self.color_var.get()),('primary_color',self.primary_var.get()),('capsule_color',self.capsule_var.get()),('heading_color',self.heading_var.get()),('background_color',self.bg_var.get()),
            ('language',self.language_var.get()),('date_format',self.date_var.get()),('show_row_numbers','1' if self.row_numbers_var.get() else '0'),
            ('grid_lines','1' if self.grid_lines_var.get() else '0'),('row_select_color','1' if self.row_select_var.get() else '0'),('row_height',self.row_height_var.get()),
            ('update_notify','1' if self.update_notify_var.get() else '0'),('sounds','1' if self.sounds_var.get() else '0'),('autosave_settings','1' if self.autosave_var.get() else '0'),
            ('confirm_delete','1' if self.confirm_delete_var.get() else '0'),('backup_path',self.backup_path_var.get()),('backup_frequency',self.backup_frequency_var.get()),
            ('update_auto_check','1' if self.update_auto_var.get() else '0'),('update_server',self.update_server_var.get()),('language_hijri','1' if self.hijri_var.get() else '0')
        ]
        for k,v in values:self.set_setting(k,v)
        global SOUNDS_ON
        SOUNDS_ON=self.get_setting('sounds')=='1'
        self.load_preferences(); self.apply_theme(); self.refresh()
        new_code=self._lang_code()
        if new_code!=I18N.code:
            if getattr(self,'_lang_prompted',None)!=new_code:
                self._lang_prompted=new_code
                if messagebox.askyesno('اللغة','لتطبيق اللغة الجديدة يجب إعادة تشغيل البرنامج. هل تريد إعادة التشغيل الآن؟'): return self._restart_app()
        else: self._lang_prompted=None
        if not silent: messagebox.showinfo('تم','تم حفظ الإعدادات وتطبيقها الآن')
    def _restart_app(self):
        try:
            env=dict(os.environ); env['FA_RESTART']='1'
            subprocess.Popen([sys.executable,str(Path(__file__).resolve())],cwd=str(BASE_DIR),env=env)
        except Exception as e:
            log_error('restart: '+repr(e)); return messagebox.showerror('خطأ','تعذر إعادة التشغيل تلقائياً. أغلق البرنامج وافتحه يدوياً.')
        self.root.destroy()
    def change_password(self):
        if hashlib.sha256(self.old_pw.get().encode()).hexdigest()!=self.get_setting('password_hash'): return messagebox.showerror('خطأ','كلمة السر الحالية غير صحيحة')
        if len(self.new_pw.get())<4: return messagebox.showwarning('تنبيه','كلمة السر يجب أن تكون 4 أحرف/أرقام على الأقل')
        if self.new_pw.get()!=self.confirm_pw.get(): return messagebox.showwarning('تنبيه','تأكيد كلمة السر غير مطابق')
        self.set_setting('password_hash',hashlib.sha256(self.new_pw.get().encode()).hexdigest()); self.old_pw.set(''); self.new_pw.set(''); self.confirm_pw.set(''); messagebox.showinfo('تم','تم تغيير كلمة السر بنجاح')
    def _backup_folder(self):
        return Path(self.get_setting('backup_path').strip() or (DATA_DIR/'Backups'))
    def _backup_to(self,folder):
        folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
        target=folder/f"fixed_assets_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sqlite"
        self.conn.commit()
        dst=sqlite3.connect(str(target))
        try: self.conn.backup(dst)
        finally: dst.close()
        files=sorted(folder.glob('fixed_assets_backup_*.sqlite'),key=lambda p:p.stat().st_mtime)
        for old in files[:-30]:
            try: old.unlink()
            except Exception: pass
        return target
    def create_backup(self):
        try:
            target=self._backup_to(self.backup_path_var.get().strip() or (DATA_DIR/'Backups'))
            messagebox.showinfo('النسخ الاحتياطي',f'تم إنشاء النسخة الاحتياطية بنجاح:\n{target}',parent=self.root)
        except Exception as e:
            log_error('backup: '+repr(e)); messagebox.showerror('خطأ النسخ الاحتياطي',str(e),parent=self.root)
    def _auto_backup(self):
        try:
            days={'يومي':1,'أسبوعي':7,'شهري':30}.get(self.get_setting('backup_frequency') or 'أسبوعي',7)
            folder=self._backup_folder()
            files=sorted(folder.glob('fixed_assets_backup_*.sqlite'),key=lambda p:p.stat().st_mtime) if folder.exists() else []
            if files and (time.time()-files[-1].stat().st_mtime)<days*86400: return
            self._backup_to(folder)
        except Exception as e:
            log_error('auto backup: '+repr(e))

    def populate_list(self,table,lb): lb.delete(0,'end'); [lb.insert('end',r[0]) for r in self.q(f'SELECT name FROM {table} ORDER BY name')]
    def list_selected(self,lb,var):
        s=lb.curselection()
        if s: var.set(lb.get(s[0]))
    def add_list_value(self,table,var):
        if not var.get().strip(): return
        try:self.q(f'INSERT INTO {table}(name) VALUES(?)',(var.get().strip(),)); self.commit(); self.refresh_settings_lists(); var.set('')
        except sqlite3.IntegrityError: messagebox.showwarning('تنبيه','القيمة موجودة مسبقًا')
    def edit_list_value(self,table,var):
        old=var.get().strip()
        if not old:return
        new=self.prompt('تعديل القيمة',old)
        if new is None or not new.strip():return
        dep={'divisions':('employees','division'),'units_list':('employees','unit_name'),'categories':('items','category'),'item_units':('items','unit')}.get(table)
        try:
            self.q(f'UPDATE {table} SET name=? WHERE name=?',(new.strip(),old))
            if dep: self.q(f'UPDATE {dep[0]} SET {dep[1]}=? WHERE {dep[1]}=?',(new.strip(),old))
            self.commit(); self.refresh_settings_lists(); var.set('')
        except sqlite3.IntegrityError:messagebox.showwarning('تنبيه','القيمة موجودة مسبقًا')
    def delete_list_value(self,table,var):
        v=var.get().strip()
        if not v:return
        if self._confirm('تأكيد',f'حذف «{v}»؟'): self.q(f'DELETE FROM {table} WHERE name=?',(v,)); self.commit(); self.refresh_settings_lists(); var.set('')
    def refresh_settings_lists(self):
        for table,varname in [('divisions','division'),('units_list','unit'),('categories','category'),('item_units','itemunit')]:
            lb=getattr(self,varname+'_setting_list',None)
            if lb:self.populate_list(table,lb)
        self.refresh()
    def prompt(self,title,initial=''):
        win=tk.Toplevel(self.root); win.title(title); win.geometry('380x140'); win.transient(self.root); win.grab_set(); v=tk.StringVar(value=initial); ttk.Label(win,text=title,anchor='e').pack(fill='x',padx=15,pady=8); e=ttk.Entry(win,textvariable=v,justify='right'); e.pack(fill='x',padx=15); e.focus_set(); result=[None]
        def ok():result[0]=v.get();win.destroy()
        ttk.Button(win,text='حفظ',command=ok).pack(pady=10); win.bind('<Return>',lambda _:ok()); self.root.wait_window(win); return result[0]
    # CRUD
    def add_employee(self):
        self.employee_dialog()
    def employee_selected(self,_=None):
        # الاختيار يجهز السجل للتعديل، ولا يفتح نافذة تلقائيًا.
        return
    def employee_double_click(self, event=None):
        s=self.et.selection()
        if not s: return
        try: employee_id=int(self.et.item(s[0],'values')[0])
        except Exception: return
        self.show_employee_liability_print(employee_id)

    def show_employee_liability_print(self, employee_id):
        emp=self.q('SELECT name,division,unit_name,job FROM employees WHERE id=?',(employee_id,)).fetchone()
        if not emp: return
        rows=self.q('''SELECT i.name,i.category,i.unit,
            COALESCE(SUM(CASE WHEN t.to_employee=? THEN t.qty ELSE 0 END),0)-
            COALESCE(SUM(CASE WHEN t.from_employee=? THEN t.qty ELSE 0 END),0) AS qty
            FROM transactions t JOIN items i ON i.id=t.item_id
            WHERE (t.to_employee=? OR t.from_employee=?) AND i.active=1
            GROUP BY i.id,i.name,i.category,i.unit
            HAVING qty>0 ORDER BY i.name''',(employee_id,employee_id,employee_id,employee_id)).fetchall()
        win=tk.Toplevel(self.root); win.title(f'ذمة الموظف - {emp[0]}'); win.geometry('900x620'); win.transient(self.root)
        outer=self.scroll_body(win,18)
        ttk.Label(outer,text='ذمة الموظف',anchor='e',font=(self.font_family,18,'bold')).pack(fill='x')
        ttk.Label(outer,text=emp[0],anchor='e',font=(self.font_family,16,'bold')).pack(fill='x',pady=(4,10))
        info=ttk.Frame(outer); info.pack(fill='x',pady=(0,10))
        ttk.Label(info,text=f'الشعبة: {emp[1] or "-"}',anchor='e').pack(side='right',padx=12)
        ttk.Label(info,text=f'الوحدة: {emp[2] or "-"}',anchor='e').pack(side='right',padx=12)
        ttk.Label(info,text=f'الوظيفة: {emp[3] or "-"}',anchor='e').pack(side='right',padx=12)
        tree=self.tree(outer,['item','category','unit','qty'],['المادة','التصنيف','الوحدة','العدد']); tree.pack(fill='both',expand=True)
        for r in rows: tree.insert('', 'end', values=r)
        tree.configure(height=max(3,min(len(rows),12)))
        total=sum(int(r[3] or 0) for r in rows)
        ttk.Label(outer,text=f'إجمالي المواد: {len(rows)}   |   إجمالي الكميات: {total}',anchor='e',font=(self.font_family,self.font_size,'bold')).pack(fill='x',pady=8)
        def do_print():
            th=''.join(f'<th>{html.escape(str(x))}</th>' for x in ['المادة','التصنيف','الوحدة','العدد'])
            trs=''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in r)+'</tr>' for r in rows)
            doc=f'''<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>ذمة الموظف - {html.escape(emp[0])}</title><style>body{{font-family:Tahoma,Arial;direction:rtl;margin:35px;color:#111}}h1{{text-align:center;margin-bottom:5px}}.meta{{text-align:right;margin:18px 0;line-height:1.9}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #555;padding:9px;text-align:center}}th:first-child,td:first-child{{text-align:right}}th{{background:#e9eef3}}.total{{margin-top:15px;font-weight:bold}}.sig{{margin-top:80px;text-align:center;width:280px;margin-right:auto;margin-left:80px}}.line{{border-top:1px solid #222;margin-top:45px;padding-top:8px}}</style></head><body><h1>كشف ذمة الموظف</h1><div class="meta"><b>اسم الموظف:</b> {html.escape(emp[0])}<br><b>الشعبة:</b> {html.escape(emp[1] or '-')}<br><b>الوحدة:</b> {html.escape(emp[2] or '-')}<br><b>الوظيفة:</b> {html.escape(emp[3] or '-')}<br><b>تاريخ الطباعة:</b> {self.now()}</div><table><thead><tr>{th}</tr></thead><tbody>{trs}</tbody></table><div class="total">إجمالي المواد: {len(rows)} &nbsp;&nbsp; إجمالي الكميات: {total}</div><div class="sig"><div class="line">اسم الموظف: {html.escape(emp[0])}</div><div>التوقيع: __________________</div></div><script>window.onload=()=>window.print()</script></body></html>'''
            doc=self._print_doc(doc)
            path=Path(tempfile.gettempdir())/'Employee_Liability_print.html'; path.write_text(doc,encoding='utf-8'); webbrowser.open(path.as_uri())
        ttk.Button(outer,text='🖨️ طباعة الذمة',command=do_print).pack(side='right',pady=8)
        ttk.Button(outer,text='إغلاق',command=win.destroy).pack(side='right',padx=8,pady=8)

    def edit_employee(self):
        s=self.et.selection()
        if not s:return messagebox.showwarning('تنبيه','حدد الموظف المراد تعديله')
        i=self.et.item(s[0],'values')[0]
        self.employee_dialog(int(i))
    def delete_employee(self):
        s=self.et.selection()
        if not s:return messagebox.showwarning('تنبيه','حدد الموظف')
        i=self.et.item(s[0],'values')[0]
        if self.q('SELECT 1 FROM transactions WHERE from_employee=? OR to_employee=? LIMIT 1',(i,i)).fetchone():
            return messagebox.showwarning('لا يمكن الحذف','الموظف لديه حركات مسجلة. يمكنك تعديله أو إبقاؤه ضمن السجل.')
        if self._confirm('تأكيد','حذف الموظف؟'):
            self.q('DELETE FROM employees WHERE id=?',(i,)); self.commit(); self.refresh()

    def add_item(self):
        self.item_dialog()
    def item_selected(self,_=None):
        return

    def item_double_click(self, event=None):
        if not hasattr(self, 'it'): return
        s=self.it.selection()
        if not s: return
        try:
            item_id=int(self.it.item(s[0], 'values')[0])
        except Exception:
            return
        self.show_item_details(item_id)

    def show_item_details(self, item_id):
        item=self.q('SELECT id,name,category,unit,note FROM items WHERE id=?',(item_id,)).fetchone()
        if not item: return
        win=tk.Toplevel(self.root)
        win.title(f'معلومات المادة - {item[1]}')
        win.geometry('820x570'); win.minsize(700,480); win.transient(self.root); win.grab_set()
        outer=self.scroll_body(win,18)
        ttk.Label(outer,text='معلومات المادة والذمم',anchor='e',font=(self.font_family,17,'bold')).pack(fill='x',pady=(0,12))

        info=ttk.LabelFrame(outer,text='بيانات المادة',padding=10); info.pack(fill='x',pady=(0,10))
        for label,value in [('اسم المادة',item[1]),('التصنيف',item[2] or '-'),('الوحدة',item[3] or '-'),('رصيد المخزن',str(self.stock(item_id))),('ملاحظات',item[4] or '-')]:
            row=ttk.Frame(info); row.pack(fill='x',pady=3)
            ttk.Label(row,text=label,width=16,anchor='e').pack(side='right',padx=5)
            ttk.Label(row,text=value,anchor='e').pack(side='right',fill='x',expand=True,padx=5)

        holders=ttk.LabelFrame(outer,text='المواد الموجودة بذمم الموظفين',padding=10); holders.pack(fill='both',expand=True)
        cols=['id','employee','division','unit_name','qty']
        heads=['الرقم','اسم الموظف','الشعبة','الوحدة','العدد']
        tree=self.tree(holders,cols,heads); tree.pack(fill='both',expand=True)
        rows=[]
        emps=self.q('SELECT id,name,division,unit_name FROM employees WHERE active=1 ORDER BY name').fetchall()
        for eid,name,division,unit_name in emps:
            q=int(self.held(item_id,eid) or 0)
            if q>0:
                rows.append((eid,name,division or '',unit_name or '',q))
                tree.insert('', 'end', values=(eid,name,division or '',unit_name or '',q))

        tree.configure(height=max(3,min(len(rows),12)))
        total_held=sum(r[4] for r in rows)
        total_stock=int(self.stock(item_id) or 0)
        summary=ttk.Frame(outer); summary.pack(fill='x',pady=(10,0))
        ttk.Label(summary,text=f'عدد الموظفين: {len(rows)}',font=(self.font_family,self.font_size,'bold')).pack(side='right',padx=10)
        ttk.Label(summary,text=f'إجمالي الكمية عند الموظفين: {total_held}',font=(self.font_family,self.font_size,'bold')).pack(side='right',padx=10)
        ttk.Label(summary,text=f'المتبقي في المخزن: {total_stock}',font=(self.font_family,self.font_size,'bold')).pack(side='right',padx=10)
        ttk.Button(outer,text='🖨️ طباعة تفاصيل المادة',command=lambda:self.print_tree(tree,f'تفاصيل مادة: {item[1]}')).pack(anchor='e',pady=(10,0))
        ttk.Button(outer,text='إغلاق',command=win.destroy).pack(anchor='e',pady=(6,0))
    def edit_item(self):
        s=self.it.selection()
        if not s:return messagebox.showwarning('تنبيه','حدد الصنف المراد تعديله')
        i=self.it.item(s[0],'values')[0]
        self.item_dialog(int(i))
    def delete_item(self):
        s=self.it.selection()
        if not s:return messagebox.showwarning('تنبيه','حدد الصنف')
        i=self.it.item(s[0],'values')[0]
        if self.q('SELECT 1 FROM stock_receipts WHERE item_id=? UNION SELECT 1 FROM transactions WHERE item_id=? UNION SELECT 1 FROM stock_out WHERE item_id=? LIMIT 1',(i,i,i)).fetchone():return messagebox.showwarning('لا يمكن الحذف','الصنف لديه حركات مسجلة. عدّله بدل حذفه للحفاظ على السجل.')
        if self._confirm('تأكيد','حذف المادة؟'):
            self.q('DELETE FROM items WHERE id=?',(i,));self.commit();self.load_items();self.refresh()

    def load_items(self):
        if not hasattr(self,'it'): return
        self.clear(self.it)
        s='%'+getattr(self,'item_search',tk.StringVar()).get().strip()+'%'
        rows=self.q('SELECT id,name,category,unit,note FROM items WHERE active=1 AND name LIKE ? ORDER BY name',(s,))
        for i,n,c,u,note in rows:
            held=self.q("SELECT COALESCE(SUM(CASE WHEN to_employee IS NOT NULL THEN qty ELSE 0 END),0)-COALESCE(SUM(CASE WHEN from_employee IS NOT NULL THEN qty ELSE 0 END),0) FROM transactions WHERE item_id=?",(i,)).fetchone()[0]
            total=int(self.stock(i) or 0)+int(held or 0); self.it.insert('','end',values=(i,n,c,u,self.stock(i),held,total,note))

    def clear_item_form(self):
        self.iname.set('');self.icat.set('');self.iunit.set('قطعة');self.inote.set('')
    # helpers
    def ids(self,kind):return self.q('SELECT id,name FROM '+kind+' WHERE active=1 ORDER BY name').fetchall()
    def setcombo(self,c,rows):c['values']=[f'{i} - {n}' for i,n in rows]
    def parse(self,v):return int(v.split(' - ',1)[0]) if ' - ' in v else None
    def qty(self,v):
        try:x=int(v); assert x>0; return x
        except:raise ValueError('الكمية يجب أن تكون رقمًا صحيحًا أكبر من صفر')
    def stock(self,item):
        ins=self.q('SELECT COALESCE(SUM(qty),0) FROM stock_receipts WHERE item_id=?',(item,)).fetchone()[0];outs=self.q('SELECT COALESCE(SUM(qty),0) FROM stock_out WHERE item_id=?',(item,)).fetchone()[0];dist=self.q("SELECT COALESCE(SUM(qty),0) FROM transactions WHERE type='توزيع' AND item_id=?",(item,)).fetchone()[0];ret=self.q("SELECT COALESCE(SUM(qty),0) FROM transactions WHERE type='إرجاع' AND item_id=?",(item,)).fetchone()[0];return ins-outs-dist+ret
    def held(self,item,emp):return self.q("SELECT COALESCE(SUM(CASE WHEN to_employee=? THEN qty ELSE 0 END),0)-COALESCE(SUM(CASE WHEN from_employee=? THEN qty ELSE 0 END),0) FROM transactions WHERE item_id=?",(emp,emp,item)).fetchone()[0]
    def receipt(self):
        try:i=self.parse(self.rcitem.get());q=self.qty(self.rcqty.get());self.q('INSERT INTO stock_receipts(item_id,qty,date,doc_no,source,note) VALUES(?,?,?,?,?,?)',(i,q,self.now(),self.rcdoc.get(),self.rcsrc.get(),self.rcnote.get()));self.commit();self.refresh()
        except Exception as e:messagebox.showerror('خطأ',str(e))
    def receipt_selected(self,_=None):
        s=self.rct.selection();
        if s:
            v=self.rct.item(s[0],'values');self.rcqty.set(v[3]);self.rcdoc.set(v[4]);self.rcsrc.set(v[5]);self.rcnote.set(v[6])
    def edit_receipt(self):
        s=self.rct.selection();
        if not s:return messagebox.showwarning('تنبيه','حدد سجل الإدخال')
        self.receipt_dialog(int(self.rct.item(s[0],'values')[0])); return
        try:q=self.qty(self.rcqty.get())
        except Exception as e:return messagebox.showerror('خطأ',str(e))
        i=self.rct.item(s[0],'values')[0];item=self.rct.item(s[0],'values')[2];iid=self.parse(self.rcitem.get()) or self.q('SELECT item_id FROM stock_receipts WHERE id=?',(i,)).fetchone()[0]
        self.q('UPDATE stock_receipts SET item_id=?,qty=?,doc_no=?,source=?,note=? WHERE id=?',(iid,q,self.rcdoc.get(),self.rcsrc.get(),self.rcnote.get(),i));self.commit();self.refresh()
    def delete_receipt(self):self.delete_selected(self.rct,'stock_receipts','حذف إدخال المخزن')
    def distribute(self):
        try:i=self.parse(self.di.get());e=self.parse(self.de.get());q=self.qty(self.dq.get());
        except Exception as x:return messagebox.showerror('خطأ',str(x))
        if not i or not e:return messagebox.showerror('خطأ','اختر المادة والموظف')
        if self.stock(i)<q:return messagebox.showerror('خطأ','الكمية غير متوفرة في المخزن')
        self.q("INSERT INTO transactions(type,item_id,qty,to_employee,date,doc_no,note) VALUES('توزيع',?,?,?,?,?,?)",(i,q,e,self.now(),self.ddoc.get(),self.dnote.get()));self.commit();self.refresh()
    def distribution_selected(self,_=None):
        s=self.dist.selection();
        if s:
            v=self.dist.item(s[0],'values');self.dq.set(v[3]);self.ddoc.set(v[5]);self.dnote.set(v[6])
    def edit_distribution(self):
        s=self.dist.selection();
        if not s:return messagebox.showwarning('تنبيه','حدد سجل التوزيع')
        self.distribution_dialog(int(self.dist.item(s[0],'values')[0])); return
        tid=self.dist.item(s[0],'values')[0];old=self.q('SELECT qty,item_id,to_employee FROM transactions WHERE id=?',(tid,)).fetchone()
        try:newq=self.qty(self.dq.get())
        except Exception as e:return messagebox.showerror('خطأ',str(e))
        available=self.stock(old[1])+old[0]
        if newq>available:return messagebox.showerror('خطأ','الكمية الجديدة أكبر من المتوفر')
        self.q('UPDATE transactions SET qty=?,doc_no=?,note=? WHERE id=?',(newq,self.ddoc.get(),self.dnote.get(),tid));self.commit();self.refresh()
    def delete_distribution(self):self.delete_selected(self.dist,'transactions','حذف توزيع',"type='توزيع'")
    def transfer(self):
        try:i=self.parse(self.ti.get());a=self.parse(self.tf.get());b=self.parse(self.ttarget.get());q=self.qty(self.tq.get())
        except Exception as x:return messagebox.showerror('خطأ',str(x))
        if not all((i,a,b)):return messagebox.showerror('خطأ','اختر المادة والموظفين')
        if a==b:return messagebox.showerror('خطأ','لا يمكن التحويل لنفس الموظف')
        if self.held(i,a)<q:return messagebox.showerror('خطأ','المادة/الكمية ليست بذمة الموظف الأول')
        self.q("INSERT INTO transactions(type,item_id,qty,from_employee,to_employee,date,doc_no,reason) VALUES('تحويل',?,?,?,?,?,?,?)",(i,q,a,b,self.now(),self.tdoc.get(),self.treason.get()));self.commit();self.refresh()
    def transfer_selected(self,_=None):
        s=self.trt.selection();
        if s:
            v=self.trt.item(s[0],'values');self.tq.set(v[3]);self.tdoc.set(v[6]);self.treason.set(v[7])
    def edit_transfer(self):
        s=self.trt.selection();
        if not s:return messagebox.showwarning('تنبيه','حدد سجل التحويل')
        self.transfer_dialog(int(self.trt.item(s[0],'values')[0])); return
        tid=self.trt.item(s[0],'values')[0];old=self.q('SELECT qty,item_id,from_employee,to_employee FROM transactions WHERE id=?',(tid,)).fetchone()
        try:newq=self.qty(self.tq.get())
        except Exception as e:return messagebox.showerror('خطأ',str(e))
        if self.held(old[1],old[2])+old[0]<newq:return messagebox.showerror('خطأ','الكمية الجديدة أكبر من ذمة الموظف')
        self.q('UPDATE transactions SET qty=?,doc_no=?,reason=? WHERE id=?',(newq,self.tdoc.get(),self.treason.get(),tid));self.commit();self.refresh()
    def delete_transfer(self):self.delete_selected(self.trt,'transactions','حذف تحويل',"type='تحويل'")
    def return_item(self):
        try:i=self.parse(self.ri.get());e=self.parse(self.re.get());q=self.qty(self.rq.get())
        except Exception as x:return messagebox.showerror('خطأ',str(x))
        if not i or not e:return messagebox.showerror('خطأ','اختر المادة والموظف')
        if self.held(i,e)<q:return messagebox.showerror('خطأ','الكمية ليست بذمة الموظف')
        self.q("INSERT INTO transactions(type,item_id,qty,from_employee,date,doc_no,reason) VALUES('إرجاع',?,?,?,?,?,?)",(i,q,e,self.now(),self.rdoc.get(),self.rr.get()));self.commit();self.refresh()
    def load_return_selection(self):
        s=self.ret.selection();
        if s:
            v=self.ret.item(s[0],'values');self.rq.set(v[3]);self.rdoc.set(v[5]);self.rr.set(v[6])
    def delete_return(self):self.delete_selected(self.ret,'transactions','حذف إرجاع',"type='إرجاع'")
    def stock_out(self):
        try:i=self.parse(self.oi.get());q=self.qty(self.oq.get())
        except Exception as x:return messagebox.showerror('خطأ',str(x))
        if not i:return messagebox.showerror('خطأ','اختر المادة')
        if self.stock(i)<q:return messagebox.showerror('خطأ','الكمية غير متوفرة في المخزن')
        self.q('INSERT INTO stock_out(item_id,qty,date,doc_no,reason,extract_to) VALUES(?,?,?,?,?,?)',(i,q,self.now(),self.odoc.get(),self.oreason.get(),getattr(self,'oextract',tk.StringVar()).get()));self.commit();self.refresh()
    def load_out_selection(self):
        return
    def edit_stockout(self):
        s=self.ot.selection();
        if not s:return messagebox.showwarning('تنبيه','حدد سجل الإخراج')
        self.out_dialog(int(self.ot.item(s[0],'values')[0])); return
        oid=self.ot.item(s[0],'values')[0];old=self.q('SELECT qty,item_id FROM stock_out WHERE id=?',(oid,)).fetchone()
        try:newq=self.qty(self.oq.get())
        except Exception as e:return messagebox.showerror('خطأ',str(e))
        if self.stock(old[1])+old[0]<newq:return messagebox.showerror('خطأ','الكمية الجديدة أكبر من رصيد المخزن')
        self.q('UPDATE stock_out SET qty=?,doc_no=?,reason=? WHERE id=?',(newq,self.odoc.get(),self.oreason.get(),oid));self.commit();self.refresh()
    def delete_stockout(self):self.delete_selected(self.ot,'stock_out','حذف إخراج')
    def delete_selected(self,tree,table,title,where=''):
        s=tree.selection();
        if not s:return messagebox.showwarning('تنبيه','حدد السجل أولاً')
        i=tree.item(s[0],'values')[0]
        if self._confirm('تأكيد',title+'؟'):
            sql=f'DELETE FROM {table} WHERE id=?'+((' AND '+where) if where else '')
            self.q(sql,(i,));self.commit();self.refresh()
    def now(self):return datetime.now().strftime('%Y-%m-%d %H:%M')
    def clear(self,t):
        for x in t.get_children():t.delete(x)
    def refresh(self):
        # widgets may not exist while page is being built
        er=self.ids('employees');ir=self.ids('items')
        for attr,rows in [('rccombo',ir),('dic',ir),('tic',ir),('oc',ir),('ric',ir),('dec',er),('tfc',er),('ttc',er),('rec',er)]:
            w=getattr(self,attr,None)
            if w:self.setcombo(w,rows)
        if hasattr(self,'e_divc'): self.e_divc['values']=[n for _,n in self.q('SELECT id,name FROM divisions ORDER BY name')]; self.e_unitc['values']=[n for _,n in self.q('SELECT id,name FROM units_list ORDER BY name')]
        if hasattr(self,'icatc'):self.icatc['values']=[n for _,n in self.q('SELECT id,name FROM categories ORDER BY name')];self.iunitc['values']=[n for _,n in self.q('SELECT id,name FROM item_units ORDER BY name')]
        if hasattr(self,'et'):
            self.clear(self.et); [self.et.insert('','end',values=r) for r in self.q('SELECT id,name,COALESCE(division,\'\'),COALESCE(unit_name,\'\'),job,note FROM employees ORDER BY name')]
        if hasattr(self,'it'): self.load_items()
        if hasattr(self,'rct'):
            self.clear(self.rct); [self.rct.insert('','end',values=r) for r in self.q('SELECT r.id,r.date,i.name,r.qty,r.doc_no,r.source,r.note FROM stock_receipts r JOIN items i ON i.id=r.item_id ORDER BY r.id DESC LIMIT 500')]
        if hasattr(self,'dist'):
            self.clear(self.dist); [self.dist.insert('','end',values=r) for r in self.q("SELECT t.id,t.date,i.name,t.qty,e.name,t.doc_no,t.note FROM transactions t JOIN items i ON i.id=t.item_id JOIN employees e ON e.id=t.to_employee WHERE t.type='توزيع' ORDER BY t.id DESC LIMIT 500")]
        if hasattr(self,'trt'):
            self.clear(self.trt); [self.trt.insert('','end',values=r) for r in self.q("SELECT t.id,t.date,i.name,t.qty,e1.name,e2.name,t.doc_no,t.reason FROM transactions t JOIN items i ON i.id=t.item_id JOIN employees e1 ON e1.id=t.from_employee JOIN employees e2 ON e2.id=t.to_employee WHERE t.type='تحويل' ORDER BY t.id DESC LIMIT 500")]
        if hasattr(self,'ret'):
            self.clear(self.ret); [self.ret.insert('','end',values=r) for r in self.q("SELECT t.id,t.date,i.name,t.qty,e.name,t.doc_no,t.reason FROM transactions t JOIN items i ON i.id=t.item_id JOIN employees e ON e.id=t.from_employee WHERE t.type='إرجاع' ORDER BY t.id DESC LIMIT 500")]
        if hasattr(self,'ot'):
            self.clear(self.ot); [self.ot.insert('','end',values=r) for r in self.q('SELECT o.id,o.date,i.name,o.qty,o.doc_no,o.reason,o.extract_to FROM stock_out o JOIN items i ON i.id=o.item_id ORDER BY o.id DESC LIMIT 500')]
        if hasattr(self,'lt'):self.load_ledger()
        if hasattr(self,'held_tree'):
            self.filter_held_employees()
        if hasattr(self,'wh'): self.load_warehouse()
    def load_ledger(self):
        if not hasattr(self,'lt'):return
        self.clear(self.lt);s='%'+getattr(self,'search',tk.StringVar()).get().strip()+'%';rows=self.q("SELECT t.id,t.date,t.type,i.name,t.qty,COALESCE(e1.name,''),COALESCE(e2.name,''),t.doc_no,t.reason FROM transactions t JOIN items i ON i.id=t.item_id LEFT JOIN employees e1 ON e1.id=t.from_employee LEFT JOIN employees e2 ON e2.id=t.to_employee WHERE i.name LIKE ? OR COALESCE(e1.name,'') LIKE ? OR COALESCE(e2.name,'') LIKE ? ORDER BY t.id DESC LIMIT 1000",(s,s,s));[self.lt.insert('','end',values=r) for r in rows]
    def setcombo(self,c,rows):c['values']=[f'{i} - {n}' for i,n in rows]
    def tree(self,parent,keys,heads,height=None):
        try: _pal=self.current_palette(); _lc='#3f4a5a' if _pal['dark'] else '#c3cfdb'
        except Exception: _lc='#c3cfdb'
        _rn=self.get_setting('show_row_numbers')=='1'
        t=GridTree(parent,line_color=_lc,grid_on=(self.get_setting('grid_lines')!='0'),columns=keys,show=(('tree','headings') if _rn else 'headings'),**({'height':height} if height else {}))
        t._row_numbers=_rn; t._date_fmt=('dmy' if (self.get_setting('date_format') or 'يوم/شهر/سنة')=='يوم/شهر/سنة' else 'ymd'); t._hijri=self.get_setting('language_hijri')=='1'
        if _rn: t.column('#0',width=52,minwidth=40,anchor='center',stretch=False); t.heading('#0',text='#',anchor='center')
        for k,h in zip(keys,heads):
            t.heading(k,text=h,anchor='center')
            t.column(k,width=(125 if len(keys)<=8 else 95),minwidth=60,anchor='center',stretch=True)
        # الرقم/التسلسل يبقى داخليًا لتحديد السجل لكنه لا يظهر للمستخدم.
        visible=[k for k in keys if k not in ('id','serial','number')]
        # في الجداول التي تحتوي مادة/اسم موظف نجعلها أول عمود من اليمين.
        priority=[k for k in ('item','name') if k in visible]
        rest=[k for k in visible if k not in priority]
        desired=priority+rest
        t['displaycolumns']=list(reversed(desired))
        return t
    def _print_doc(self,doc):
        if I18N.code=='ar': return doc
        doc=I18N.tr(doc)
        return doc.replace('dir="rtl"','dir="ltr"').replace('direction:rtl','direction:ltr').replace('text-align:right','text-align:left')
    def print_tree(self,tree,title):
        if not tree or not tree.get_children():return messagebox.showinfo('الطباعة','لا توجد بيانات للطباعة')
        cols=[c for c in tree['displaycolumns'] if c not in ('id','serial','number')]
        if 'item' in cols:
            cols=[c for c in cols if c!='item']+['item']
        elif 'name' in cols:
            cols=[c for c in cols if c!='name']+['name']
        heads=[tree.heading(c)['text'] for c in reversed(cols)]
        rows=[[tree.set(i,c) for c in reversed(cols)] for i in tree.get_children()]
        th=''.join(f'<th>{html.escape(str(x))}</th>' for x in heads); trs=''.join('<tr>'+''.join(f'<td>{html.escape(str(x))}</td>' for x in r)+ '</tr>' for r in rows)
        doc=f'''<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>{html.escape(title)}</title><style>body{{font-family:Tahoma,Arial;direction:rtl;margin:25px}}h1{{text-align:right}}table{{width:100%;border-collapse:collapse}}th,td{{border:1px solid #777;padding:7px;text-align:right}}th{{background:#eee}}@media print{{button{{display:none}}}}</style></head><body><h1>{html.escape(title)}</h1><p>تاريخ الطباعة: {self.now()}</p><table><thead><tr>{th}</tr></thead><tbody>{trs}</tbody></table><button onclick="window.print()">طباعة</button><script>window.onload=()=>window.print()</script></body></html>'''
        doc=self._print_doc(doc)
        path=Path(tempfile.gettempdir())/'FixedAssets_print.html';path.write_text(doc,encoding='utf-8')
        try:
            if os.name=='nt':os.startfile(str(path),'print')
            else:webbrowser.open(path.as_uri())
        except Exception:webbrowser.open(path.as_uri())
    def theme_palette(self):
        fg_dark=self.font_color if self.font_color not in ('#111111','#000000') else '#f3f4f6'
        return {
            'فاتح':{'bg':self.background_color,'fg':self.font_color,'field':'#fff','select':self.primary_color,'card':'#ffffff','head':'#eef3f8','border':'#dce6ef','title':self.heading_color,'sub':'#64748b','dark':False},
            'متوسط':{'bg':'#dfe8ef','fg':self.font_color,'field':'#f4f7fa','select':self.primary_color,'card':'#f6f9fc','head':'#e1eaf2','border':'#c9d6e2','title':self.heading_color,'sub':'#56667a','dark':False},
            'داكن مائل':{'bg':'#1b2636','fg':fg_dark,'field':'#26354a','select':self.primary_color,'card':'#243247','head':'#2d3d55','border':'#34465f','title':'#f1f5f9','sub':'#9fb0c6','dark':True},
            'داكن':{'bg':'#1f2329','fg':fg_dark,'field':'#2b3038','select':self.primary_color,'card':'#272c33','head':'#323841','border':'#3a414b','title':'#f3f4f6','sub':'#a1a8b3','dark':True},
        }
    def current_palette(self):
        pals=self.theme_palette()
        p=dict(pals.get(self.theme_name) or pals['فاتح'])
        if p['dark']: p.update(inp=p['field'],off='#4b5563',soft_bg='#1e3a5f',soft_fg='#93c5fd',dng_bg='#4c1d1d',dng_fg='#fca5a5')
        else: p.update(inp='#ffffff',off='#cbd5e1',soft_bg='#dbeafe',soft_fg='#1d4ed8',dng_bg='#fee2e2',dng_fg='#b91c1c')
        return p
    def _nav_font(self):
        return (self.font_family,max(11,min(self.font_size+1,13)),'bold')
    def apply_theme(self):
        style=ttk.Style(self.root)
        try:style.theme_use('clam')
        except Exception:pass
        c=self.current_palette(); self.pal=c
        self._surface_color=c['field']; self._surface_header=c['head']
        wt='bold' if self.font_bold else 'normal'; fam=self.font_family; fsz=self.font_size
        prim=self.primary_color; prim_dark=_shade(prim,0.85)
        self.root.configure(bg=c['bg']); self.nav.configure(bg=NAV_BG); self.content.configure(bg=c['bg'])
        style.configure('.',font=(fam,fsz,wt),foreground=c['fg'],background=c['bg'])
        style.configure('TFrame',background=c['bg'])
        style.configure('TLabelframe',background=c['bg'],bordercolor=c['border'],lightcolor=c['border'],darkcolor=c['border'])
        style.configure('TLabelframe.Label',background=c['bg'],foreground=c['title'],font=(fam,fsz,'bold'))
        style.configure('TLabel',background=c['bg'],foreground=c['fg'])
        style.configure('TEntry',fieldbackground=c['field'],foreground=c['fg'],bordercolor=c['border'],lightcolor=c['border'],darkcolor=c['border'])
        style.configure('TCombobox',fieldbackground=c['field'],foreground=c['fg'],bordercolor=c['border'],lightcolor=c['border'],darkcolor=c['border'],arrowcolor=c['sub'])
        style.configure('TButton',font=(fam,fsz,'bold'),background=prim,foreground='#ffffff',bordercolor=prim,lightcolor=prim,darkcolor=prim,focuscolor=prim,padding=(14,6),borderwidth=0,relief='flat')
        style.map('TButton',background=[('active',prim_dark),('disabled',c['border'])],lightcolor=[('active',prim_dark)],darkcolor=[('active',prim_dark)],bordercolor=[('active',prim_dark)],foreground=[('disabled',c['sub'])])
        style.configure('Treeview',background=c['field'],fieldbackground=c['field'],foreground=c['fg'],rowheight={'صغير':max(22,fsz+11),'كبير':max(34,fsz+23)}.get(self.get_setting('row_height'),max(27,fsz+16)),font=(fam,fsz,wt),bordercolor=c['border'],lightcolor=c['border'],darkcolor=c['border'])
        lc='#3f4a5a' if c['dark'] else '#c3cfdb'; self._grid_color=lc
        style.configure('Treeview.Heading',background=c['head'],foreground=c['title'],font=(fam,fsz,'bold'),relief='flat',padding=6,borderwidth=1,bordercolor=lc,lightcolor=lc,darkcolor=lc)
        style.map('Treeview',background=[('selected',c['select'])],foreground=[('selected','#ffffff')])
        style.map('Treeview.Heading',background=[('active',c['border'])])
        style.configure('TNotebook',background=c['bg']); style.configure('TCheckbutton',background=c['bg'],foreground=c['fg'])
        # الشريط الجانبي: الخط والألوان
        nav_font=self._nav_font()
        for b in getattr(self,'buttons',{}).values():
            try: b.set_font(nav_font)
            except Exception: pass
        for hdr,inner,var in getattr(self,'sections',{}).values():
            try: hdr.configure(font=nav_font)
            except Exception: pass
        hb=getattr(self,'home_button',None)
        if hb is not None:
            try: hb.set_solid(prim)
            except Exception: pass
        # تطبيق المظهر فعليًا على عناصر Tk العادية (صفحة الإعدادات لها ألوانها الخاصة ولا تُمسّ هنا)
        surface=c['field']; button_bg=c['select']
        def paint(w):
            try:
                if w is self.nav or w.winfo_toplevel() is not self.root: return
                if getattr(w,'_custom',False): return
                cls=w.winfo_class()
                if cls in ('Frame','Labelframe'): w.configure(bg=c['bg'])
                elif cls=='Label': w.configure(bg=c['bg'],fg=c['fg'])
                elif cls=='Button': w.configure(bg=button_bg,fg='white',activebackground=button_bg,activeforeground='white')
                elif cls=='Entry': w.configure(bg=surface,fg=c['fg'],insertbackground=c['fg'])
                elif cls=='Text': w.configure(bg=surface,fg=c['fg'],insertbackground=c['fg'])
                elif cls=='Listbox': w.configure(bg=surface,fg=c['fg'],selectbackground=button_bg,selectforeground='white')
                elif cls=='Canvas': w.configure(bg=c['bg'])
                elif cls=='Checkbutton': w.configure(bg=c['bg'],fg=c['fg'],activebackground=c['bg'],activeforeground=c['fg'],selectcolor=surface)
            except Exception: pass
            for ch in w.winfo_children(): paint(ch)
        paint(self.content)
        def _gl(w):
            if isinstance(w,GridTree): w.set_line_color(lc)
            for ch in w.winfo_children(): _gl(ch)
        _gl(self.content)
        self._right_align(self.root)
    def _right_align(self,w):
        try:
            if isinstance(w,(tk.Entry,tk.Text)):w.configure(justify='right')
            if isinstance(w,tk.Listbox):w.configure(justify='right')
        except:pass
        for child in w.winfo_children():self._right_align(child)

def _show_fatal(exc_type, exc, tb, root=None):
    text=''.join(traceback.format_exception(exc_type, exc, tb))
    if isinstance(exc, DataIntegrityError):
        try: messagebox.showerror('تعذر تنفيذ العملية',str(exc))
        except Exception: pass
        return
    log_error(text)
    try: messagebox.showerror('خطأ غير متوقع','حدث خطأ غير متوقع ولم يتأثر السجل المحفوظ.\nتفاصيل الخطأ حُفظت في الملف:\n'+str(LOG_FILE))
    except Exception: pass


def main():
    ok,lock=acquire_instance_lock()
    root=tk.Tk()
    root.report_callback_exception=lambda et,ev,tb:_show_fatal(et,ev,tb,root)
    sys.excepthook=lambda et,ev,tb:_show_fatal(et,ev,tb,root)
    try: threading.excepthook=lambda a:log_error('thread: '+repr(a.exc_value))
    except Exception: pass
    if not ok:
        root.withdraw(); messagebox.showwarning('البرنامج مفتوح','البرنامج يعمل بالفعل على هذا الجهاز. أغلق النافذة الأخرى أولاً.'); root.destroy(); return
    LoginWindow(root); root.mainloop()


if __name__=='__main__':
    main()
